# Remote Control App (consent-based, Android, NO server deploy needed)

Do Android phones ke beech pairing-code se remote screen view + control (jaise
TeamViewer), family/friend ko remote help dene ke liye — **hamesha explicit
consent ke saath**. Kahin bhi koi server deploy karne ki zaroorat nahi —
dono phones ek hi WiFi par seedhe ek-dusre ko dhoondh lete hain.

## Zaroori limitation (trade-off, deploy avoid karne ka)

Dono phones ek hi WiFi network par hone chahiye (ya ek phone ka mobile
hotspot ON karke doosra usse jud jaye). Alag-alag mobile-data connections ke
beech (jaise ek Jio pe, doosra Airtel pe, dono ghar se door) ye kaam nahi
karega — uske liye internet par kahin available ek server chahiye hota hi hai,
jo humne jaan-boojh kar avoid kiya hai.

## Kaise kaam karta hai (bina server ke)

Android ka Network Service Discovery (NSD) use kiya hai — bilkul waise jaise
AirDrop ya Chromecast local WiFi par devices dhoondh lete hain:

1. Host phone code generate karta hai aur khud ko WiFi par "advertise" karta
   hai (service name me code chhupa hota hai: `RemoteControl-123456`).
2. Controller phone code daalta hai -> app WiFi par scan karke wahi service
   dhoondh leta hai jiska code match kare.
3. Match milte hi dono phones seedha ek TCP socket connection bana lete hain
   (kisi third-party ke through nahi).
4. Usi socket par WebRTC signaling (offer/answer/ICE) hoti hai, phir screen
   video aur remote taps bhi seedha phone-se-phone (peer-to-peer) jaate hain.

## Kya-kya bana hai

```
remote-control-app/
└── android-app/          -> Android Studio project (Kotlin) - bas yahi hai
    ├── app/src/main/java/com/example/remotecontrol/
    │   ├── MainActivity.kt            -> Mode choose karo: Host ya Controller
    │   ├── HostActivity.kt            -> Code dikhata hai, consent leta hai
    │   ├── ControllerActivity.kt      -> Code daalo, remote screen dekho/control karo
    │   ├── SignalingClient.kt         -> WiFi discovery + direct socket (NO cloud)
    │   ├── ScreenCaptureService.kt    -> Screen capture + WebRTC (Host side)
    │   └── RemoteAccessibilityService.kt -> Remote taps ko actual gestures banata hai
    └── app/src/main/AndroidManifest.xml
```

## Setup steps (bahut simple ab)

1. `android-app/` folder ko Android Studio me kholo (File -> Open).
2. Gradle sync hone do (pehli baar internet chahiye, dependencies download
   hongi - uske baad app khud offline/WiFi-local kaam karta hai).
3. App ko do alag Android phones (real devices - emulator me screen capture
   aur accessibility service theek se test nahi hoti) par install karo.
4. Dono phone ek hi WiFi se connect karo (ghar ka WiFi, ya ek phone ka
   hotspot on karke doosra usse jode).
5. Ek phone pe "Is phone ko madad ke liye control hone do" (Host) -> code
   milega. Doosre phone pe "Main doosra phone control karunga" (Controller) ->
   wahi code daalo - kuch second me connect ho jayega.

## Zaroori cheezein jo abhi manual hain (Android security ki wajah se, bypass nahi ho sakti)

- MediaProjection permission: Har session me Host phone par ek system popup
  aayega "Cast/record screen?" - is app ko khud-ba-khud allow karne ka koi tarika
  nahi hai, aur hona bhi nahi chahiye.
- Accessibility Service: Host phone par Settings -> Accessibility me jaake
  ek baar manually enable karna padega. Agli baar se yaad rahega.
- Launcher icon: Maine icon files nahi banayi - Android Studio me naya
  project banate waqt ye auto-generate ho jaati hain, ya res/mipmap me khud
  daal sakte ho.

## Jo cheez maine simplify ki hai (aage improve karne layak)

- Tap-coordinate scaling fraction-based (0-1) hai, mostly kaam karega lekin
  bahut alag aspect-ratio wale phones me thoda off ho sakta hai.
- WebRTC library version (io.github.webrtc-sdk:android) time ke saath update
  hoti rehti hai - build error aaye to latest version number check kar lena.
- STUN/TURN ki zaroorat nahi padi kyunki dono phone same local network par
  hain - direct LAN connection hai.
- Agar WiFi router "AP isolation" / "client isolation" mode me hai (kuch
  office/public WiFi me hota hai - devices ek-dusre ko dekh nahi paate), to
  discovery fail ho sakti hai. Ghar ka normal WiFi ya hotspot me dikkat nahi
  aani chahiye.

## Zaroori: consent aur zimmedari

Ye app sirf dono taraf ki marzi se kaam karta hai - Host phone har baar
explicit "Allow" popup dikhata hai aur session ke dauraan hamesha ek
persistent notification dikhti rehti hai. Kisi ke phone ko unki jaankari ya
sehmati ke bina control karna (chhup ke monitor karna) illegal ho sakta hai
aur bahut galat hai - is code ko us tarah modify na karein.
