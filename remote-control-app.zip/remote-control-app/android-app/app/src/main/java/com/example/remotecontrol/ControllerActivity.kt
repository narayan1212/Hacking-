package com.example.remotecontrol

import android.os.Bundle
import android.view.MotionEvent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.remotecontrol.databinding.ActivityControllerBinding
import org.json.JSONObject
import org.webrtc.*

/**
 * Ye activity us phone par chalti hai jo REMOTE CONTROL karega (jaise beta/beti
 * jo apne parent ka phone help karna chahta hai).
 *
 * Flow:
 *  1. Code daalo -> signaling server se doosre phone (host) se jud jaate ho.
 *  2. Host jab "Allow" dabata hai, hume "host-accepted" milta hai.
 *  3. Host WebRTC offer bhejta hai (usi ke paas video hai) -> hum answer bhejte hain.
 *  4. Host ki screen video yahan dikhti hai. Jahan bhi tap karo, wahi coordinates
 *     (scale karke) DataChannel se host ko bhej diye jaate hain.
 */
class ControllerActivity : AppCompatActivity(), SignalingListener {

    private lateinit var binding: ActivityControllerBinding
    private lateinit var signalingClient: SignalingClient
    private lateinit var peerConnectionFactory: PeerConnectionFactory
    private var peerConnection: PeerConnection? = null
    private var dataChannel: DataChannel? = null
    private var eglBase: EglBase = EglBase.create()

    // Host ki actual screen resolution - taps ko sahi scale karne ke liye zaroori
    private var remoteVideoWidth = 0
    private var remoteVideoHeight = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityControllerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.remoteView.init(eglBase.eglBaseContext, null)
        binding.remoteView.setEnableHardwareScaler(true)

        initWebRtcFactory()

        binding.btnJoin.setOnClickListener {
            val code = binding.etCode.text.toString().trim()
            if (code.length != 6) {
                Toast.makeText(this, "6-digit code daalo", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            binding.tvStatus.text = "Connect ho raha hai..."
            signalingClient = SignalingHub.getOrCreate(this, this)
            signalingClient.connect()
            pendingCode = code
        }

        binding.remoteView.setOnTouchListener { _, event -> handleTouch(event); true }
    }

    private var pendingCode: String? = null

    override fun onConnectionOpened() {
        pendingCode?.let { signalingClient.joinWithCode(it) }
    }

    override fun onJoined(code: String) {
        binding.tvStatus.text = "Code accept ho gaya. Doosre phone ke allow karne ka wait ho raha hai..."
    }

    override fun onHostAccepted() {
        binding.tvStatus.text = "Connect ho gaya. Video load ho raha hai..."
    }

    override fun onHostRejected() {
        binding.tvStatus.text = "Doosre phone ne request deny kar di."
    }

    private fun initWebRtcFactory() {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(applicationContext)
                .createInitializationOptions()
        )
        val encoderFactory = DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true)
        val decoderFactory = DefaultVideoDecoderFactory(eglBase.eglBaseContext)
        peerConnectionFactory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(encoderFactory)
            .setVideoDecoderFactory(decoderFactory)
            .createPeerConnectionFactory()
    }

    private fun setupPeerConnection() {
        val iceServers = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
        )
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers)

        peerConnection = peerConnectionFactory.createPeerConnection(
            rtcConfig,
            object : PeerConnection.Observer {
                override fun onIceCandidate(candidate: IceCandidate) {
                    signalingClient.sendIceCandidate(
                        candidate.sdpMid, candidate.sdpMLineIndex, candidate.sdp
                    )
                }
                override fun onDataChannel(channel: DataChannel) {
                    dataChannel = channel
                    dataChannel?.registerObserver(object : DataChannel.Observer {
                        override fun onBufferedAmountChange(amount: Long) {}
                        override fun onStateChange() {}
                        override fun onMessage(buffer: DataChannel.Buffer) {}
                    })
                }
                override fun onTrack(transceiver: RtpTransceiver) {
                    val track = transceiver.receiver.track()
                    if (track is VideoTrack) {
                        runOnUiThread {
                            track.addSink(binding.remoteView)
                        }
                    }
                }
                override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {}
                override fun onConnectionChange(state: PeerConnection.PeerConnectionState) {}
                override fun onSignalingChange(state: PeerConnection.SignalingState) {}
                override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {}
                override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>) {}
                override fun onAddStream(stream: MediaStream) {}
                override fun onRemoveStream(stream: MediaStream) {}
                override fun onRenegotiationNeeded() {}
            }
        )
    }

    override fun onWebRtcOffer(sdp: String) {
        setupPeerConnection()
        val desc = SessionDescription(SessionDescription.Type.OFFER, sdp)
        peerConnection?.setRemoteDescription(object : SimpleSdpObserver() {
            override fun onSetSuccess() {
                val constraints = MediaConstraints()
                peerConnection?.createAnswer(object : SdpObserver {
                    override fun onCreateSuccess(answer: SessionDescription) {
                        peerConnection?.setLocalDescription(SimpleSdpObserver(), answer)
                        signalingClient.sendAnswer(answer.description)
                    }
                    override fun onSetSuccess() {}
                    override fun onCreateFailure(error: String) {}
                    override fun onSetFailure(error: String) {}
                }, constraints)
            }
        }, desc)
    }

    override fun onIceCandidate(sdpMid: String, sdpMLineIndex: Int, candidate: String) {
        peerConnection?.addIceCandidate(IceCandidate(sdpMid, sdpMLineIndex, candidate))
    }

    private fun handleTouch(event: MotionEvent) {
        if (event.action != MotionEvent.ACTION_DOWN) return
        val channel = dataChannel ?: return

        // View ke pixel coordinates ko host screen ke actual resolution me scale karo
        val viewWidth = binding.remoteView.width.toFloat()
        val viewHeight = binding.remoteView.height.toFloat()
        if (viewWidth == 0f || viewHeight == 0f) return

        // NOTE: production me remote screen ka actual width/height signaling ke
        // through pehle bhejna chahiye taaki scaling exact ho. Yahan simplification
        // ke taur par view-relative fraction (0..1) bheja ja raha hai aur host side
        // par usi fraction ko apne screen-size se multiply karna hoga.
        val fractionX = event.x / viewWidth
        val fractionY = event.y / viewHeight

        val json = JSONObject()
            .put("action", "tap")
            .put("xFraction", fractionX)
            .put("yFraction", fractionY)

        val buffer = DataChannel.Buffer(
            java.nio.ByteBuffer.wrap(json.toString().toByteArray()), false
        )
        channel.send(buffer)
    }

    override fun onSessionEnded() {
        binding.tvStatus.text = "Session khatam ho gaya."
    }

    override fun onPeerDisconnected() {
        binding.tvStatus.text = "Doosra device disconnect ho gaya."
    }

    override fun onCodeExpired() {
        binding.tvStatus.text = "Code expire ho gaya."
    }

    override fun onError(message: String) {
        binding.tvStatus.text = "Error: $message"
    }

    override fun onConnectionClosed() {}

    override fun onDestroy() {
        super.onDestroy()
        dataChannel?.close()
        peerConnection?.close()
        binding.remoteView.release()
        SignalingHub.closeAndClear()
    }
}
