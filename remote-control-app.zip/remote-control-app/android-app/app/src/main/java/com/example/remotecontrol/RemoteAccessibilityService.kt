package com.example.remotecontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import org.json.JSONObject

/**
 * User ko ise Settings > Accessibility me MANUALLY enable karna padta hai —
 * Android jaan-boojh kar ye process automate hone nahi deta, taaki koi app
 * silently apne aap accessibility permission na le sake. Ye important
 * security/consent boundary hai, isko bypass karne ki koshish mat karna.
 *
 * Ye service sirf remote se aaye JSON commands ko actual screen gestures
 * (tap / swipe) me convert karti hai. Ye kisi cheez ko "padhti" ya record
 * nahi karti (canRetrieveWindowContent=false, config file me).
 */
class RemoteAccessibilityService : AccessibilityService() {

    companion object {
        var instance: RemoteAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Hume window content padhna nahi hai, sirf gestures perform karne hain.
    }

    override fun onInterrupt() {}

    fun performRemoteAction(json: JSONObject) {
        when (json.optString("action")) {
            "tap" -> {
                val x = json.optDouble("x").toFloat()
                val y = json.optDouble("y").toFloat()
                dispatchTap(x, y)
            }
            "swipe" -> {
                val x1 = json.optDouble("x1").toFloat()
                val y1 = json.optDouble("y1").toFloat()
                val x2 = json.optDouble("x2").toFloat()
                val y2 = json.optDouble("y2").toFloat()
                val duration = json.optLong("durationMs", 300L)
                dispatchSwipe(x1, y1, x2, y2, duration)
            }
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        }
    }

    private fun dispatchTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    private fun dispatchSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
}
