package com.example.remotecontrol

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.remotecontrol.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // "Is phone ko control hone do" -> HostActivity (code generate karke dikhayega)
        binding.btnBeControlled.setOnClickListener {
            startActivity(Intent(this, HostActivity::class.java))
        }

        // "Main doosra phone control karunga" -> ControllerActivity (code daalna hoga)
        binding.btnControlOther.setOnClickListener {
            startActivity(Intent(this, ControllerActivity::class.java))
        }
    }
}
