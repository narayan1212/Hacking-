package com.example.remotecontrol

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.ServerSocket
import java.net.Socket
import kotlin.random.Random

/**
 * ============================================================================
 *  NO CLOUD SERVER VERSION
 * ============================================================================
 * Ye pehle cloud (Render/Railway) signaling server use karta tha. Ab uski
 * jagah dono phones seedhe WiFi par ek-dusre ko dhoondhte hain
 * (Android Network Service Discovery - jaise AirDrop/Chromecast kaam karta
 * hai) aur ek direct TCP socket bana lete hain. Isliye:
 *
 *   - Kahin bhi deploy karne ki zaroorat NAHI
 *   - Koi server URL configure nahi karna
 *   - Dono phones ek hi WiFi network (ya ek phone ka mobile hotspot) par
 *     hone chahiye - alag-alag mobile-data networks ke beech kaam nahi
 *     karega (uske liye internet-par-available server hi chahiye hota,
 *     jo hum jaan-boojh kar avoid kar rahe hain)
 *
 * Baaki poori app (HostActivity, ControllerActivity, ScreenCaptureService)
 * bilkul waisi hi rehti hai - unhe pata bhi nahi chalta ki signaling ab
 * WiFi-local hai, kyunki yahan wahi purana SignalingListener interface aur
 * method names maintain kiye gaye hain.
 */

private const val SERVICE_TYPE = "_remotectrl._tcp."
private const val SERVICE_NAME_PREFIX = "RemoteControl-"

interface SignalingListener {
    fun onCodeCreated(code: String) {}
    fun onControllerJoined() {}
    fun onJoined(code: String) {}
    fun onHostAccepted() {}
    fun onHostRejected() {}
    fun onWebRtcOffer(sdp: String) {}
    fun onWebRtcAnswer(sdp: String) {}
    fun onIceCandidate(sdpMid: String, sdpMLineIndex: Int, candidate: String) {}
    fun onSessionEnded() {}
    fun onPeerDisconnected() {}
    fun onCodeExpired() {}
    fun onError(message: String) {}
    fun onConnectionOpened() {}
    fun onConnectionClosed() {}
}

/** App-wide singleton, taaki Activity aur Service ek hi live socket share kar sakein. */
object SignalingHub {
    var client: SignalingClient? = null
        private set

    fun getOrCreate(listener: SignalingListener, context: Context): SignalingClient {
        val existing = client
        return if (existing != null) {
            existing.listener = listener
            existing
        } else {
            SignalingClient(listener, context.applicationContext).also { client = it }
        }
    }

    fun closeAndClear() {
        client?.disconnect()
        client = null
    }
}

class SignalingClient(var listener: SignalingListener, private val appContext: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val nsdManager = appContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val wifiManager = appContext.applicationContext
        .getSystemService(Context.WIFI_SERVICE) as WifiManager

    private var serverSocket: ServerSocket? = null
    private var connectedSocket: Socket? = null
    private var writer: OutputStreamWriter? = null
    private var readThread: Thread? = null
    private var registrationListener: NsdManager.RegistrationListener? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private var targetCode: String? = null

    /** Activity ke onCreate se call hota hai - is version me sirf "ready" state mein aata hai. */
    fun connect() {
        post { listener.onConnectionOpened() }
    }

    // ---------------- HOST side: code generate karo + advertise karo ----------------

    fun requestHostCode() {
        val code = (100000 + Random.nextInt(900000)).toString()
        try {
            val server = ServerSocket(0) // OS khud ek free port choose karega
            serverSocket = server

            val serviceInfo = NsdServiceInfo().apply {
                serviceName = SERVICE_NAME_PREFIX + code
                serviceType = SERVICE_TYPE
                port = server.localPort
            }

            registrationListener = object : NsdManager.RegistrationListener {
                override fun onServiceRegistered(info: NsdServiceInfo) {
                    post {
                        listener.onCodeCreated(code)
                    }
                }
                override fun onRegistrationFailed(info: NsdServiceInfo, errorCode: Int) {
                    post { listener.onError("WiFi advertise nahi ho paya (code $errorCode). WiFi on hai?") }
                }
                override fun onServiceUnregistered(info: NsdServiceInfo) {}
                override fun onUnregistrationFailed(info: NsdServiceInfo, errorCode: Int) {}
            }
            nsdManager.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, registrationListener)

            // Background me controller ke connect hone ka wait karo
            Thread {
                try {
                    val socket = server.accept() // yahan block hoga jab tak koi connect na kare
                    onSocketConnected(socket)
                    post { listener.onControllerJoined() }
                } catch (e: Exception) {
                    // server socket close hua (session cancel ya khatam) - normal hai
                }
            }.start()
        } catch (e: Exception) {
            post { listener.onError("Server start nahi ho saka: ${e.message}") }
        }
    }

    // ---------------- CONTROLLER side: code daalo -> WiFi par dhoondo ----------------

    fun joinWithCode(code: String) {
        targetCode = code
        acquireMulticastLock()

        discoveryListener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}

            override fun onServiceFound(service: NsdServiceInfo) {
                if (!service.serviceName.startsWith(SERVICE_NAME_PREFIX)) return
                val foundCode = service.serviceName.removePrefix(SERVICE_NAME_PREFIX)
                if (foundCode != targetCode) return // koi aur session hai, humara nahi

                nsdManager.resolveService(service, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                        post { listener.onError("Device mila lekin connect nahi ho paya") }
                    }
                    override fun onServiceResolved(info: NsdServiceInfo) {
                        stopDiscovery()
                        connectToHost(info.host.hostAddress, info.port, code)
                    }
                })
            }

            override fun onServiceLost(service: NsdServiceInfo) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                post { listener.onError("WiFi par dhoondhna start nahi hua (code $errorCode)") }
            }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
        }
        nsdManager.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener)
    }

    private fun connectToHost(host: String?, port: Int, code: String) {
        if (host == null) {
            post { listener.onError("Host ka address nahi mila") }
            return
        }
        Thread {
            try {
                val socket = Socket(host, port)
                onSocketConnected(socket)
                post { listener.onJoined(code) }
            } catch (e: Exception) {
                post { listener.onError("Connect nahi ho paya: ${e.message}. Same WiFi par hain dono phone?") }
            }
        }.start()
    }

    // ---------------- Common: ek baar socket ban jaye to dono taraf same ----------------

    private fun onSocketConnected(socket: Socket) {
        connectedSocket = socket
        writer = OutputStreamWriter(socket.getOutputStream())
        val reader = BufferedReader(InputStreamReader(socket.getInputStream()))

        readThread = Thread {
            try {
                while (true) {
                    val line = reader.readLine() ?: break
                    handleMessage(line)
                }
            } catch (e: Exception) {
                // socket band ho gaya
            }
            post { listener.onPeerDisconnected() }
        }
        readThread?.start()
    }

    private fun handleMessage(text: String) {
        val json = try { JSONObject(text) } catch (e: Exception) { return }
        when (json.optString("type")) {
            "host-accepted" -> post { listener.onHostAccepted() }
            "host-rejected" -> post { listener.onHostRejected() }
            "webrtc-offer" -> post { listener.onWebRtcOffer(json.getString("sdp")) }
            "webrtc-answer" -> post { listener.onWebRtcAnswer(json.getString("sdp")) }
            "webrtc-ice-candidate" -> post {
                listener.onIceCandidate(
                    json.getString("sdpMid"),
                    json.getInt("sdpMLineIndex"),
                    json.getString("candidate")
                )
            }
            "end-session" -> post { listener.onSessionEnded() }
        }
    }

    fun sendHostConsent(allowed: Boolean) {
        send(JSONObject().put("type", if (allowed) "host-accepted" else "host-rejected"))
    }

    fun sendOffer(sdp: String) {
        send(JSONObject().put("type", "webrtc-offer").put("sdp", sdp))
    }

    fun sendAnswer(sdp: String) {
        send(JSONObject().put("type", "webrtc-answer").put("sdp", sdp))
    }

    fun sendIceCandidate(sdpMid: String, sdpMLineIndex: Int, candidate: String) {
        send(
            JSONObject()
                .put("type", "webrtc-ice-candidate")
                .put("sdpMid", sdpMid)
                .put("sdpMLineIndex", sdpMLineIndex)
                .put("candidate", candidate)
        )
    }

    fun endSession() {
        send(JSONObject().put("type", "end-session"))
    }

    private fun send(json: JSONObject) {
        try {
            writer?.write(json.toString() + "\n")
            writer?.flush()
        } catch (e: Exception) {
            post { listener.onError("Message bhej nahi paye: ${e.message}") }
        }
    }

    private fun acquireMulticastLock() {
        multicastLock = wifiManager.createMulticastLock("remotecontrol-nsd").apply {
            setReferenceCounted(true)
            acquire()
        }
    }

    private fun stopDiscovery() {
        try {
            discoveryListener?.let { nsdManager.stopServiceDiscovery(it) }
        } catch (e: Exception) { /* already stopped */ }
        discoveryListener = null
        multicastLock?.let { if (it.isHeld) it.release() }
    }

    private fun post(action: () -> Unit) = mainHandler.post(action)

    fun disconnect() {
        try { registrationListener?.let { nsdManager.unregisterService(it) } } catch (e: Exception) {}
        stopDiscovery()
        try { readThread?.interrupt() } catch (e: Exception) {}
        try { connectedSocket?.close() } catch (e: Exception) {}
        try { serverSocket?.close() } catch (e: Exception) {}
        writer = null
        connectedSocket = null
        serverSocket = null
    }
}
