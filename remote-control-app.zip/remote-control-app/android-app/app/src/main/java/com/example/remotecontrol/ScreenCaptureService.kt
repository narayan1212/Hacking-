package com.example.remotecontrol

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import org.webrtc.*
import java.nio.charset.Charset

/**
 * Ye service us phone par chalti hai jo CONTROL kiya ja raha hai (Host).
 * Kaam:
 *   1. MediaProjection permission (Activity se already li ja chuki hai) use karke
 *      screen capture shuru karta hai.
 *   2. WebRTC PeerConnection banata hai, screen ko video track ki tarah add karta
 *      hai, aur "control" naam ka DataChannel banata hai (jispe controller ke
 *      taps aayenge).
 *   3. Offer create karke signaling server ke through controller ko bhejta hai.
 *   4. DataChannel pe aane wale JSON tap-commands ko RemoteAccessibilityService
 *      tak forward karta hai, jo unhe actual screen gestures me convert karti hai.
 *   5. Poore time ek persistent notification dikhata hai (consent/transparency
 *      ke liye zaroori — user ko hamesha pata rahe ki session live hai).
 */
class ScreenCaptureService : Service(), SignalingListener {

    companion object {
        var isRunning = false
            private set

        private const val CHANNEL_ID = "remote_control_active"
        private const val NOTIF_ID = 1001

        private const val EXTRA_RESULT_CODE = "resultCode"
        private const val EXTRA_DATA = "data"
        private const val EXTRA_CODE = "signalingCode"

        fun start(context: Context, resultCode: Int, data: Intent, signalingCode: String) {
            val intent = Intent(context, ScreenCaptureService::class.java).apply {
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_DATA, data)
                putExtra(EXTRA_CODE, signalingCode)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ScreenCaptureService::class.java))
        }
    }

    private lateinit var signalingClient: SignalingClient
    private lateinit var peerConnectionFactory: PeerConnectionFactory
    private var peerConnection: PeerConnection? = null
    private var dataChannel: DataChannel? = null
    private var eglBase: EglBase = EglBase.create()

    private var mediaProjectionResultCode: Int = 0
    private var mediaProjectionData: Intent? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        initWebRtc()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY

        mediaProjectionResultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        mediaProjectionData = intent.getParcelableExtra(EXTRA_DATA)
        val signalingCode = intent.getStringExtra(EXTRA_CODE).orEmpty()

        startForeground(NOTIF_ID, buildNotification())
        isRunning = true

        signalingClient = SignalingHub.getOrCreate(this, this)
        setupPeerConnectionAndStartCapture()

        return START_NOT_STICKY
    }

    // ---------- WebRTC setup ----------

    private fun initWebRtc() {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(applicationContext)
                .createInitializationOptions()
        )
        val encoderFactory = DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true)
        val decoderFactory = DefaultVideoDecoderFactory(eglBase.eglBaseContext)
        peerConnectionFactory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(encoderFactory)
            .setVideoDecoderFactory(decoderFactory)
            .createPeerConnectionFactory()
    }

    private fun setupPeerConnectionAndStartCapture() {
        val iceServers = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
        )
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers)

        peerConnection = peerConnectionFactory.createPeerConnection(
            rtcConfig,
            object : PeerConnection.Observer {
                override fun onIceCandidate(candidate: IceCandidate) {
                    signalingClient.sendIceCandidate(
                        candidate.sdpMid, candidate.sdpMLineIndex, candidate.sdp
                    )
                }
                override fun onDataChannel(channel: DataChannel) { /* host khud data channel banata hai */ }
                override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {}
                override fun onConnectionChange(state: PeerConnection.PeerConnectionState) {
                    if (state == PeerConnection.PeerConnectionState.DISCONNECTED ||
                        state == PeerConnection.PeerConnectionState.FAILED
                    ) {
                        stopSelf()
                    }
                }
                override fun onSignalingChange(state: PeerConnection.SignalingState) {}
                override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {}
                override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>) {}
                override fun onAddStream(stream: MediaStream) {}
                override fun onRemoveStream(stream: MediaStream) {}
                override fun onRenegotiationNeeded() {}
                override fun onTrack(transceiver: RtpTransceiver) {}
            }
        )

        // Control data-channel: controller isi pe tap-commands bhejega
        val dcInit = DataChannel.Init()
        dataChannel = peerConnection?.createDataChannel("control", dcInit)
        dataChannel?.registerObserver(object : DataChannel.Observer {
            override fun onBufferedAmountChange(amount: Long) {}
            override fun onStateChange() {}
            override fun onMessage(buffer: DataChannel.Buffer) {
                val bytes = ByteArray(buffer.data.remaining())
                buffer.data.get(bytes)
                val text = String(bytes, Charset.forName("UTF-8"))
                handleControlMessage(text)
            }
        })

        startScreenCapture()
        createOffer()
    }

    private fun startScreenCapture() {
        val data = mediaProjectionData ?: return
        val capturer = ScreenCapturerAndroid(
            data,
            object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }
        )
        val surfaceTextureHelper =
            SurfaceTextureHelper.create("CaptureThread", eglBase.eglBaseContext)
        val videoSource = peerConnectionFactory.createVideoSource(true)
        capturer.initialize(surfaceTextureHelper, applicationContext, videoSource.capturerObserver)

        val metrics = resources.displayMetrics
        capturer.startCapture(metrics.widthPixels, metrics.heightPixels, 30)

        val videoTrack = peerConnectionFactory.createVideoTrack("screen_video", videoSource)
        peerConnection?.addTrack(videoTrack, listOf("screen_stream"))
    }

    private fun createOffer() {
        val constraints = MediaConstraints()
        peerConnection?.createOffer(object : SdpObserver {
            override fun onCreateSuccess(desc: SessionDescription) {
                peerConnection?.setLocalDescription(SimpleSdpObserver(), desc)
                signalingClient.sendOffer(desc.description)
            }
            override fun onSetSuccess() {}
            override fun onCreateFailure(error: String) {}
            override fun onSetFailure(error: String) {}
        }, constraints)
    }

    private fun handleControlMessage(text: String) {
        // Controller "xFraction"/"yFraction" (0..1, view-relative) bhejta hai taaki
        // dono phones ki screen resolution alag hone par bhi tap sahi jagah pade.
        // Yahan hum use is phone ki actual pixel resolution me convert karte hain.
        val json = try { JSONObject(text) } catch (e: Exception) { return }
        val metrics = resources.displayMetrics

        val converted = JSONObject(json.toString())
        if (json.has("xFraction") && json.has("yFraction")) {
            converted.put("x", json.getDouble("xFraction") * metrics.widthPixels)
            converted.put("y", json.getDouble("yFraction") * metrics.heightPixels)
        }
        RemoteAccessibilityService.instance?.performRemoteAction(converted)
    }

    // ---------- Signaling callbacks ----------

    override fun onWebRtcAnswer(sdp: String) {
        val desc = SessionDescription(SessionDescription.Type.ANSWER, sdp)
        peerConnection?.setRemoteDescription(SimpleSdpObserver(), desc)
    }

    override fun onIceCandidate(sdpMid: String, sdpMLineIndex: Int, candidate: String) {
        peerConnection?.addIceCandidate(IceCandidate(sdpMid, sdpMLineIndex, candidate))
    }

    override fun onSessionEnded() { stopSelf() }
    override fun onPeerDisconnected() { stopSelf() }
    override fun onError(message: String) {}

    // ---------- Notification (consent/transparency) ----------

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Remote control active", NotificationManager.IMPORTANCE_HIGH
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Remote control session active")
            .setContentText("Koi is phone ki screen dekh/control kar sakta hai. Band karne ke liye tap karo.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .build()
    }

    override fun onDestroy() {
        isRunning = false
        dataChannel?.close()
        peerConnection?.close()
        SignalingHub.closeAndClear()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

/** SdpObserver ke saare methods implement karne se bachne ke liye chhota helper */
open class SimpleSdpObserver : SdpObserver {
    override fun onCreateSuccess(desc: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(error: String?) {}
    override fun onSetFailure(error: String?) {}
}
