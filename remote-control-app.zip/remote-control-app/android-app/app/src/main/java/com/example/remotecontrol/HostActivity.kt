package com.example.remotecontrol

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.remotecontrol.databinding.ActivityHostBinding

/**
 * Ye activity us phone par chalti hai jise CONTROL kiya jaayega (jaise
 * "mummy-papa ka phone" jisko aap help karna chahte ho).
 *
 * Flow:
 *  1. Signaling server se connect hoke ek 6-digit code maangta hai.
 *  2. Code doosre insaan ko bhejo (call/message se) taaki wo apne phone me daale.
 *  3. Jaise hi controller join kare, "Allow?" popup dikhta hai - user ki
 *     explicit permission ke bina session shuru NAHI hota.
 *  4. Allow karne par: (a) MediaProjection permission maangi jaati hai
 *     (screen capture ke liye - ye Android khud maangta hai, bypass nahi ho sakta),
 *     (b) Accessibility Service enable karne ke liye Settings khulti hai agar
 *     already enabled nahi hai.
 *  5. Poore session me ek persistent notification dikhti rehti hai.
 */
class HostActivity : AppCompatActivity(), SignalingListener {

    private lateinit var binding: ActivityHostBinding
    private lateinit var signalingClient: SignalingClient
    private lateinit var mediaProjectionManager: MediaProjectionManager
    private var currentCode: String? = null

    private val screenCapturePermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                ScreenCaptureService.start(
                    context = this,
                    resultCode = result.resultCode,
                    data = result.data!!,
                    signalingCode = currentCode.orEmpty()
                )
                binding.tvStatus.text = "Session active. Controller connected ho gaya."
            } else {
                binding.tvStatus.text = "Screen-share permission allow nahi hui, session cancel."
                signalingClient.sendHostConsent(false)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHostBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mediaProjectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        binding.tvStatus.text = "Server se connect ho raha hai..."
        signalingClient = SignalingHub.getOrCreate(this, this)
        signalingClient.connect()
    }

    override fun onConnectionOpened() {
        signalingClient.requestHostCode()
    }

    override fun onCodeCreated(code: String) {
        currentCode = code
        binding.tvCode.text = code
        binding.tvStatus.text = "Ye code doosre insaan ko bhejo. Unke join karne ka wait ho raha hai..."
    }

    override fun onControllerJoined() {
        AlertDialog.Builder(this)
            .setTitle("Remote control request")
            .setMessage(
                "Ek device ne connect hone ki request bheji hai.\n\n" +
                    "Allow karne par wo aapki screen dekh sakega aur taps bhej sakega, " +
                    "jab tak aap session end na karo."
            )
            .setCancelable(false)
            .setPositiveButton("Allow") { _, _ ->
                signalingClient.sendHostConsent(true)
                checkAccessibilityAndRequestScreenCapture()
            }
            .setNegativeButton("Deny") { _, _ ->
                signalingClient.sendHostConsent(false)
                binding.tvStatus.text = "Request deny ki gayi."
            }
            .show()
    }

    private fun checkAccessibilityAndRequestScreenCapture() {
        if (!isAccessibilityServiceEnabled()) {
            AlertDialog.Builder(this)
                .setTitle("Ek aur step baaki hai")
                .setMessage(
                    "Remote taps kaam karne ke liye 'Remote Control' Accessibility " +
                        "Service ko enable karna hoga. Agli screen me ise ON karo, phir wapas aa jao."
                )
                .setPositiveButton("Settings kholo") { _, _ ->
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                .setCancelable(false)
                .show()
            return
        }
        binding.tvStatus.text = "Screen-share permission maangi ja rahi hai..."
        screenCapturePermissionLauncher.launch(mediaProjectionManager.createScreenCaptureIntent())
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expectedComponent = "$packageName/${RemoteAccessibilityService::class.java.name}"
        val enabledServices = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.contains(expectedComponent)
    }

    override fun onResume() {
        super.onResume()
        // Jab user Accessibility settings se wapas aaye, dubara try karo
        if (currentCode != null && isAccessibilityServiceEnabled() && !ScreenCaptureService.isRunning) {
            // dobara consent-flow trigger karne ki zaroorat nahi, sirf tab jab pehle rok gaya ho
        }
    }

    override fun onHostRejected() {}

    override fun onSessionEnded() {
        binding.tvStatus.text = "Session khatam ho gaya."
        ScreenCaptureService.stop(this)
    }

    override fun onPeerDisconnected() {
        binding.tvStatus.text = "Doosra device disconnect ho gaya."
        ScreenCaptureService.stop(this)
    }

    override fun onCodeExpired() {
        binding.tvStatus.text = "Code expire ho gaya, wapas try karo."
    }

    override fun onError(message: String) {
        binding.tvStatus.text = "Error: $message"
    }

    override fun onConnectionClosed() {}

    override fun onDestroy() {
        super.onDestroy()
        // Note: signaling connection ko yahan close NAHI karte - agar
        // ScreenCaptureService abhi bhi chal rahi hai to usse WebRTC signaling
        // ke liye isi connection ki zaroorat hai. Service khud session end/
        // disconnect hone par SignalingHub.closeAndClear() call karti hai.
        if (!ScreenCaptureService.isRunning) {
            SignalingHub.closeAndClear()
        }
    }
}
