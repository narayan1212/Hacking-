plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.remotecontrol"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.remotecontrol"
        minSdk = 26          // MediaProjection + modern Accessibility APIs ke liye
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")

    // WebRTC (maintained community build of Google's WebRTC for Android)
    implementation("io.github.webrtc-sdk:android:125.6422.06.1")

    // JSON (local socket messages ke liye)
    implementation("org.json:json:20240303")
}
