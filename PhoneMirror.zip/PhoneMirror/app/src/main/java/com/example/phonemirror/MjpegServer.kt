package com.example.phonemirror

import android.content.Context
import fi.iki.elonen.NanoWSD
import org.json.JSONObject
import java.io.PipedInputStream
import java.io.PipedOutputStream

/**
 * Runs entirely on the phone. No cloud/internet server involved -
 * only reachable from devices on the same local WiFi network.
 *
 * Routes:
 *   GET  /            -> viewer.html (the control page you open on your PC browser)
 *   GET  /stream       -> MJPEG multipart video feed of the phone screen
 *   WS   /control       -> two-way channel:
 *          viewer -> phone commands: tap / swipe / text / key / openUrl
 *          phone -> viewer status: whether Accessibility Service is enabled
 *
 * Command handling itself lives in ControlCommandRouter, shared with the
 * internet relay transport (RelayClient) so both behave identically.
 */
class MjpegServer(port: Int, private val context: Context) : NanoWSD(port) {

    private val boundary = "phonemirrorboundary"

    override fun serveHttp(session: IHTTPSession): Response {
        return when (session.uri) {
            "/", "/index.html" -> {
                val html = context.assets.open("viewer.html").bufferedReader().use { it.readText() }
                newFixedLengthResponse(Response.Status.OK, "text/html", html)
            }
            "/stream" -> streamMjpeg()
            else -> super.serveHttp(session)
        }
    }

    /** Streams JPEG frames forever as multipart/x-mixed-replace (standard MJPEG format). */
    private fun streamMjpeg(): Response {
        val pipedOut = PipedOutputStream()
        val pipedIn = PipedInputStream(pipedOut, 1024 * 1024)

        Thread {
            try {
                while (true) {
                    val frame = ScreenCaptureService.latestFrameJpeg
                    if (frame != null) {
                        val header = "--$boundary\r\nContent-Type: image/jpeg\r\nContent-Length: ${frame.size}\r\n\r\n"
                        pipedOut.write(header.toByteArray())
                        pipedOut.write(frame)
                        pipedOut.write("\r\n".toByteArray())
                        pipedOut.flush()
                    }
                    Thread.sleep(100) // ~10 fps, adjust for smoother/lower-bandwidth streaming
                }
            } catch (e: Exception) {
                // Viewer disconnected - end the frame-pushing thread quietly
            }
        }.start()

        val response = newChunkedResponse(
            Response.Status.OK,
            "multipart/x-mixed-replace; boundary=$boundary",
            pipedIn
        )
        response.addHeader("Cache-Control", "no-cache")
        return response
    }

    override fun openWebSocket(handshake: IHTTPSession): WebSocket {
        return object : WebSocket(handshake) {

            override fun onOpen() {
                // Tell the viewer right away whether it can actually control the phone,
                // so it can show a clear warning instead of silently doing nothing.
                sendStatus(this)
            }

            override fun onClose(code: WebSocketFrame.CloseCode?, reason: String?, initiatedByRemote: Boolean) {}

            override fun onMessage(message: WebSocketFrame) {
                try {
                    val json = JSONObject(message.textPayload)
                    if (json.optString("type") == "ping") {
                        sendStatus(this)
                    } else {
                        ControlCommandRouter.handle(json, context)
                    }
                } catch (e: Exception) {
                    // ignore malformed messages
                }
            }

            override fun onPong(pong: WebSocketFrame?) {}
            override fun onException(exception: java.io.IOException?) {}

            private fun sendStatus(ws: WebSocket) {
                try {
                    ws.send(ControlCommandRouter.buildStatusJson(context).toString())
                } catch (e: Exception) {
                    // connection may already be closed
                }
            }
        }
    }
}
