package com.example.phonemirror

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        findViewById<MaterialCardView>(R.id.cardShare).setOnClickListener {
            startActivity(Intent(this, ShareOptionsActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardView).setOnClickListener {
            startActivity(Intent(this, ViewOptionsActivity::class.java))
        }
    }
}
