package com.example.phonemirror

object NsdConstants {
    // Custom local network service type this app registers/discovers under.
    // Every phone that taps "Start Mirroring" advertises itself under this type,
    // and every phone on "Find Devices" looks for exactly this type.
    const val SERVICE_TYPE = "_phonemirror._tcp."
}
