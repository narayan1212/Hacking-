package com.example.phonemirror

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject

/**
 * Executes a control command received from a viewer, regardless of whether it arrived
 * over the local WebSocket (MjpegServer) or the internet relay (RelayClient). Keeping
 * this in one place means both transports behave identically and stay in sync.
 */
object ControlCommandRouter {

    fun handle(json: JSONObject, context: Context) {
        when (json.optString("type")) {
            "tap" -> {
                TapAccessibilityService.performTapAt(
                    json.getDouble("x").toFloat(),
                    json.getDouble("y").toFloat()
                )
            }
            "swipe" -> {
                TapAccessibilityService.performSwipe(
                    json.getDouble("x1").toFloat(),
                    json.getDouble("y1").toFloat(),
                    json.getDouble("x2").toFloat(),
                    json.getDouble("y2").toFloat(),
                    json.optLong("duration", 300L)
                )
            }
            "text" -> {
                TapAccessibilityService.typeText(json.getString("value"))
            }
            "key" -> {
                when (json.getString("action")) {
                    "back" -> TapAccessibilityService.pressBack()
                    "home" -> TapAccessibilityService.pressHome()
                    "recents" -> TapAccessibilityService.pressRecents()
                }
            }
            "openUrl" -> {
                openUrlOnPhone(json.getString("url"), context)
            }
        }
    }

    private fun openUrlOnPhone(rawUrl: String, context: Context) {
        val url = if (rawUrl.startsWith("http://") || rawUrl.startsWith("https://")) {
            rawUrl
        } else {
            "https://$rawUrl"
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    /** Builds the same status payload both transports send to let the viewer know
     * whether tap control is actually connected right now. */
    fun buildStatusJson(context: Context): JSONObject {
        var connected = TapAccessibilityService.isEnabled()
        val enabledInSettings = TapAccessibilityService.isEnabledInSystemSettings(context)
        var stuck = enabledInSettings && !connected

        if (stuck) {
            TapAccessibilityService.attemptSelfHeal(context)
            connected = TapAccessibilityService.isEnabled()
            stuck = enabledInSettings && !connected
        }

        return JSONObject().apply {
            put("type", "status")
            put("accessibilityEnabled", connected)
            put("accessibilityEnabledInSettings", enabledInSettings)
            put("stuck", stuck)
        }
    }
}
