package com.example.phonemirror

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.material.card.MaterialCardView

/**
 * Shown right after the user picks "Share My Screen" on the home screen.
 * Lets them choose whether to share over the local WiFi network (MainActivity)
 * or over the internet using a relay + code (InternetShareActivity).
 */
class ShareOptionsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_share_options)

        findViewById<Toolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }

        findViewById<MaterialCardView>(R.id.cardShareWifi).setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardShareInternet).setOnClickListener {
            startActivity(Intent(this, InternetShareActivity::class.java))
        }
    }
}
