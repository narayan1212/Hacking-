package com.example.phonemirror

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityManager
import android.view.accessibility.AccessibilityNodeInfo

/**
 * User must manually enable this once in Settings > Accessibility (Android does not allow
 * apps to turn this on for themselves - it's a deliberate anti-malware protection).
 *
 * This service is the only thing on Android allowed to actually inject gestures / text
 * on behalf of another app. It receives commands from MjpegServer (which gets them from
 * the browser viewer over WebSocket) and performs the real action on the phone.
 */
class TapAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        private var instance: TapAccessibilityService? = null

        fun isEnabled(): Boolean = instance != null

        /**
         * True when Android's Settings > Accessibility toggle for this service is ON,
         * according to the OS itself - regardless of whether our own [instance] is
         * currently connected. On some phones, after a WiFi/network state change or a
         * period in the background, the toggle stays visually ON but the service's
         * connection silently drops (a known OEM/Android reliability bug, not something
         * an app can fully prevent). Comparing this against [isEnabled] lets us tell the
         * user the precise state instead of a generic "control is off" message.
         */
        fun isEnabledInSystemSettings(context: Context): Boolean {
            return try {
                val expected = android.content.ComponentName(context, TapAccessibilityService::class.java)
                val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
                val enabledServices = am.getEnabledAccessibilityServiceList(
                    AccessibilityServiceInfo.FEEDBACK_ALL_MASK
                )
                enabledServices.any {
                    val info = it.resolveInfo.serviceInfo
                    android.content.ComponentName(info.packageName, info.name) == expected
                }
            } catch (e: Exception) {
                false
            }
        }

        fun performTapAt(x: Float, y: Float) {
            instance?.dispatchTap(x, y)
        }

        fun performSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
            instance?.dispatchSwipe(x1, y1, x2, y2, durationMs)
        }

        fun typeText(text: String) {
            instance?.setTextOnFocusedField(text)
        }

        fun pressBack() {
            instance?.performGlobalAction(GLOBAL_ACTION_BACK)
        }

        fun pressHome() {
            instance?.performGlobalAction(GLOBAL_ACTION_HOME)
        }

        fun pressRecents() {
            instance?.performGlobalAction(GLOBAL_ACTION_RECENTS)
        }

        @Volatile private var lastSelfHealAttemptMs = 0L
        private const val SELF_HEAL_COOLDOWN_MS = 15_000L

        /**
         * Forces Android to tear down and rebuild this service's live binding, WITHOUT
         * touching the user's Settings > Accessibility toggle (that toggle is a separate
         * OS-level list this app is never allowed to write to - see the class doc).
         *
         * Why this is needed: on some OEM builds (Xiaomi/MIUI, ColorOS, FuntouchOS, and
         * similar aggressive battery managers), a WiFi state change or a period in the
         * background can silently kill just this service's connection while leaving the
         * Settings toggle showing ON and the rest of the app (screen capture/mirroring)
         * running fine. Re-flipping the Settings switch does NOT reliably fix that "stuck"
         * state - but disabling and re-enabling the service's own component does, because
         * it forces Android's AccessibilityManagerService to notice the component changed
         * and rebind it. This is a standard recovery technique for accessibility-based
         * apps and never grants a new permission - it only "kicks" a service the user has
         * already approved.
         *
         * Rate-limited so a persistently stuck state doesn't spam this every few seconds.
         * Returns true if an attempt was made.
         */
        fun attemptSelfHeal(context: Context): Boolean {
            val now = System.currentTimeMillis()
            if (isEnabled()) return false // already connected, nothing to heal
            if (!isEnabledInSystemSettings(context)) return false // not the "stuck" case
            if (now - lastSelfHealAttemptMs < SELF_HEAL_COOLDOWN_MS) return false
            lastSelfHealAttemptMs = now

            return try {
                val pm = context.packageManager
                val component = android.content.ComponentName(context, TapAccessibilityService::class.java)
                pm.setComponentEnabledSetting(
                    component,
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
                )
                pm.setComponentEnabledSetting(
                    component,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    PackageManager.DONT_KILL_APP
                )
                true
            } catch (e: Exception) {
                false
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    private fun dispatchTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun dispatchSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }

    /** Sets text on whatever input field currently has focus on the phone's screen. */
    private fun setTextOnFocusedField(text: String) {
        val root = rootInActiveWindow ?: return
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        val args = Bundle()
        args.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text
        )
        focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
