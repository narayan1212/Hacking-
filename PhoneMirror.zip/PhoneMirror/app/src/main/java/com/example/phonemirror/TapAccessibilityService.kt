package com.example.phonemirror

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * User must manually enable this once in Settings > Accessibility (Android does not allow
 * apps to turn this on for themselves - it's a deliberate anti-malware protection).
 *
 * This service is the only thing on Android allowed to actually inject gestures / text
 * on behalf of another app. It receives commands from MjpegServer (which gets them from
 * the browser viewer over WebSocket) and performs the real action on the phone.
 */
class TapAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        private var instance: TapAccessibilityService? = null

        fun isEnabled(): Boolean = instance != null

        fun performTapAt(x: Float, y: Float) {
            instance?.dispatchTap(x, y)
        }

        fun performSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
            instance?.dispatchSwipe(x1, y1, x2, y2, durationMs)
        }

        fun typeText(text: String) {
            instance?.setTextOnFocusedField(text)
        }

        fun pressBack() {
            instance?.performGlobalAction(GLOBAL_ACTION_BACK)
        }

        fun pressHome() {
            instance?.performGlobalAction(GLOBAL_ACTION_HOME)
        }

        fun pressRecents() {
            instance?.performGlobalAction(GLOBAL_ACTION_RECENTS)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    private fun dispatchTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun dispatchSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }

    /** Sets text on whatever input field currently has focus on the phone's screen. */
    private fun setTextOnFocusedField(text: String) {
        val root = rootInActiveWindow ?: return
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        val args = Bundle()
        args.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text
        )
        focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
