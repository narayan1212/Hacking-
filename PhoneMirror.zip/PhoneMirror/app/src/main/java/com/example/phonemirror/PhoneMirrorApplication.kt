package com.example.phonemirror

import android.app.Application
import com.google.android.gms.ads.MobileAds

class PhoneMirrorApplication : Application() {

    lateinit var appOpenAdManager: AppOpenAdManager
        private set

    override fun onCreate() {
        super.onCreate()
        MobileAds.initialize(this) {}
        appOpenAdManager = AppOpenAdManager(this)
    }
}
