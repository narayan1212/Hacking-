package com.example.phonemirror

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import android.graphics.Bitmap
import android.graphics.Color

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvUrl: TextView
    private lateinit var ivQr: ImageView
    private lateinit var statusDot: View
    private lateinit var btnStart: MaterialButton
    private lateinit var btnStop: MaterialButton

    private val screenCaptureLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val intent = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra("resultCode", result.resultCode)
                    putExtra("data", result.data)
                }
                startForegroundService(intent)
                val url = "http://${getLocalIpAddress()}:8080"
                tvStatus.text = "Sharing is active. Open this address on the other device's browser " +
                    "(same WiFi network, or connect it to this phone's hotspot):"
                tvUrl.text = url
                tvUrl.visibility = View.VISIBLE
                showQr(url)
                setStatusDotColor(R.color.colorSuccess)
                setSharingUiState(isSharing = true)
            } else {
                tvStatus.text = "Permission denied. Mirroring could not be started."
                setStatusDotColor(R.color.colorWarning)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        toolbar.setNavigationOnClickListener { finish() }

        tvStatus = findViewById(R.id.tvStatus)
        tvUrl = findViewById(R.id.tvUrl)
        ivQr = findViewById(R.id.ivQr)
        statusDot = findViewById(R.id.statusDot)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)

        btnStart.setOnClickListener {
            suppressNextAppOpenAd()
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            screenCaptureLauncher.launch(mgr.createScreenCaptureIntent())
        }

        btnStop.setOnClickListener { stopSharing() }

        findViewById<MaterialButton>(R.id.btnAccessibility).setOnClickListener {
            // Accessibility services cannot be enabled programmatically (Android security
            // restriction) - user must flip it on manually the first time.
            suppressNextAppOpenAd()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<MaterialButton>(R.id.btnFixReliability).setOnClickListener {
            showReliabilityFixDialog()
        }

        tvUrl.setOnClickListener {
            val text = tvUrl.text?.toString().orEmpty()
            if (text.isNotBlank()) {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Phone Mirror URL", text))
                Toast.makeText(this, "Link copied to clipboard", Toast.LENGTH_SHORT).show()
            }
        }

        if (isScreenCaptureServiceRunning()) {
            // Mirroring keeps running in the background (stopWithTask="false"), so if the
            // user left this screen and came back, show the real state instead of always
            // defaulting to "Start Mirroring" - otherwise Stop Sharing would be unreachable
            // until they force-close the app.
            val url = "http://${getLocalIpAddress()}:8080"
            tvStatus.text = "Sharing is active. Open this address on the other device's browser " +
                "(same WiFi network, or connect it to this phone's hotspot):"
            tvUrl.text = url
            tvUrl.visibility = View.VISIBLE
            showQr(url)
            setStatusDotColor(R.color.colorSuccess)
            setSharingUiState(isSharing = true)
        }
    }

    /** Checks whether this app's own ScreenCaptureService is currently running. Since API 26,
     * getRunningServices() only ever returns the calling app's own services, which is exactly
     * what's needed here - no extra permission required. */
    private fun isScreenCaptureServiceRunning(): Boolean {
        val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
        @Suppress("DEPRECATION")
        return am.getRunningServices(Integer.MAX_VALUE).any {
            it.service.className == ScreenCaptureService::class.java.name
        }
    }

    /** Stops mirroring: tears down the server, screen capture and NSD advertisement
     * (all handled in ScreenCaptureService.onDestroy()) and resets this screen back
     * to its "not sharing" state. */
    private fun stopSharing() {
        stopService(Intent(this, ScreenCaptureService::class.java))
        tvStatus.text = "Not sharing yet. Tap Start Mirroring below to begin."
        tvUrl.visibility = View.GONE
        ivQr.setImageBitmap(null)
        setStatusDotColor(R.color.colorIdle)
        setSharingUiState(isSharing = false)
        Toast.makeText(this, "Sharing stopped", Toast.LENGTH_SHORT).show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_credits) {
            startActivity(Intent(this, CreditsActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    /**
     * "Control keeps disconnecting" is almost always caused by the phone's OWN battery
     * manager silently killing the Accessibility Service to save power, even while a
     * foreground service keeps running - this is a well-documented behavior on MIUI,
     * ColorOS, FuntouchOS, and similar. No app can override this from code (Android
     * deliberately doesn't allow apps to force themselves to stay alive against the OS's
     * will - that's an anti-malware protection). This dialog walks through the actual
     * settings that fix it for good.
     */
    private fun showReliabilityFixDialog() {
        AlertDialog.Builder(this)
            .setTitle("Fix \"control keeps disconnecting\"")
            .setMessage(
                "This happens when the phone's battery manager kills the Accessibility " +
                    "Service in the background - a phone-brand battery setting, not a bug in " +
                    "this app. Two steps fix it for good:\n\n" +
                    "1. Battery: set this app to \"No restrictions\" / \"Don't optimize\" " +
                    "(next screen)\n\n" +
                    "2. Autostart: in your phone's Security/Battery app, find \"Autostart\" " +
                    "or \"Allow background activity\" and turn it ON for Phone Mirror\n\n" +
                    "On Xiaomi/MIUI specifically, there's one more that fully solves it: " +
                    "Settings → Additional settings → Developer options → turn OFF " +
                    "\"MIUI optimization\", then reboot."
            )
            .setPositiveButton("Open Battery Settings") { _, _ ->
                requestBatteryOptimizationExemption()
            }
            .setNeutralButton("Open App Info") { _, _ ->
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        .setData(Uri.parse("package:$packageName"))
                )
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun requestBatteryOptimizationExemption() {
        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            !powerManager.isIgnoringBatteryOptimizations(packageName)
        ) {
            suppressNextAppOpenAd()
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                // Some OEM ROMs block this intent - fall back to the general battery screen.
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        } else {
            Toast.makeText(this, "Battery optimization is already off for this app", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setSharingUiState(isSharing: Boolean) {
        btnStart.visibility = if (isSharing) View.GONE else View.VISIBLE
        btnStop.visibility = if (isSharing) View.VISIBLE else View.GONE
    }

    private fun setStatusDotColor(colorRes: Int) {
        statusDot.background.setTint(ContextCompat.getColor(this, colorRes))
    }

    /**
     * Finds this phone's own local IPv4 address so the other device can browse to it.
     *
     * Old approach used WifiManager.connectionInfo.ipAddress, which only works when
     * THIS phone is a WiFi *client* (joined someone else's WiFi/router). It returns
     * 0/garbage when this phone is instead running its own Hotspot (AP mode), because
     * in that mode the phone isn't "connected" to a WiFi network as a client.
     *
     * Fix: scan all active network interfaces directly and read the IPv4 address off
     * whichever one is actually up. This works the same way whether this phone is on
     * someone else's WiFi (interface usually "wlan0") or running its own hotspot
     * (interface name varies by device: "wlan0", "ap0", "swlan0", etc).
     */
    private fun getLocalIpAddress(): String {
        try {
            val interfaces = java.net.NetworkInterface.getNetworkInterfaces()
            val otherCandidates = mutableListOf<String>()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (!iface.isUp || iface.isLoopback) continue
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (addr is java.net.Inet4Address && !addr.isLoopbackAddress) {
                        val ip = addr.hostAddress ?: continue
                        // WiFi-client interface ("wlan0") or hotspot/AP interface
                        // ("ap0", "swlan0", etc) - either way this is the address
                        // the other device needs to browse to.
                        val name = iface.name.lowercase()
                        if (name.contains("wlan") || name.contains("ap") || name.contains("swlan")) {
                            return ip
                        }
                        otherCandidates.add(ip)
                    }
                }
            }
            // Fallback: any private-range IPv4 address found on any interface.
            otherCandidates.firstOrNull {
                it.startsWith("192.168.") || it.startsWith("10.") || it.startsWith("172.")
            }?.let { return it }
            otherCandidates.firstOrNull()?.let { return it }
        } catch (e: Exception) {
            // Fall through to the WifiManager fallback below.
        }

        // Last-resort fallback (only correct in plain WiFi-client mode).
        val wifiManager = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val ipInt = wifiManager.connectionInfo.ipAddress
        return "${ipInt and 0xff}.${ipInt shr 8 and 0xff}.${ipInt shr 16 and 0xff}.${ipInt shr 24 and 0xff}"
    }

    private fun showQr(text: String) {
        val writer = QRCodeWriter()
        val matrix = writer.encode(text, BarcodeFormat.QR_CODE, 512, 512)
        val bmp = Bitmap.createBitmap(512, 512, Bitmap.Config.RGB_565)
        for (x in 0 until 512) {
            for (y in 0 until 512) {
                bmp.setPixel(x, y, if (matrix.get(x, y)) Color.BLACK else Color.WHITE)
            }
        }
        ivQr.setImageBitmap(bmp)
    }
}
