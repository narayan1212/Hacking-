package com.example.phonemirror

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import android.graphics.Bitmap
import android.graphics.Color

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvUrl: TextView
    private lateinit var ivQr: ImageView
    private lateinit var statusDot: View

    private val screenCaptureLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val intent = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra("resultCode", result.resultCode)
                    putExtra("data", result.data)
                }
                startForegroundService(intent)
                val url = "http://${getLocalIpAddress()}:8080"
                tvStatus.text = "Sharing is active. Open this address on the other device's browser " +
                    "(same WiFi network, or connect it to this phone's hotspot):"
                tvUrl.text = url
                tvUrl.visibility = View.VISIBLE
                showQr(url)
                setStatusDotColor(R.color.colorSuccess)
            } else {
                tvStatus.text = "Permission denied. Mirroring could not be started."
                setStatusDotColor(R.color.colorWarning)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        toolbar.setNavigationOnClickListener { finish() }

        tvStatus = findViewById(R.id.tvStatus)
        tvUrl = findViewById(R.id.tvUrl)
        ivQr = findViewById(R.id.ivQr)
        statusDot = findViewById(R.id.statusDot)

        findViewById<MaterialButton>(R.id.btnStart).setOnClickListener {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            screenCaptureLauncher.launch(mgr.createScreenCaptureIntent())
        }

        findViewById<MaterialButton>(R.id.btnAccessibility).setOnClickListener {
            // Accessibility services cannot be enabled programmatically (Android security
            // restriction) - user must flip it on manually the first time.
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        tvUrl.setOnClickListener {
            val text = tvUrl.text?.toString().orEmpty()
            if (text.isNotBlank()) {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Phone Mirror URL", text))
                Toast.makeText(this, "Link copied to clipboard", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_credits) {
            startActivity(Intent(this, CreditsActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setStatusDotColor(colorRes: Int) {
        statusDot.background.setTint(ContextCompat.getColor(this, colorRes))
    }

    /**
     * Finds this phone's own local IPv4 address so the other device can browse to it.
     *
     * Old approach used WifiManager.connectionInfo.ipAddress, which only works when
     * THIS phone is a WiFi *client* (joined someone else's WiFi/router). It returns
     * 0/garbage when this phone is instead running its own Hotspot (AP mode), because
     * in that mode the phone isn't "connected" to a WiFi network as a client.
     *
     * Fix: scan all active network interfaces directly and read the IPv4 address off
     * whichever one is actually up. This works the same way whether this phone is on
     * someone else's WiFi (interface usually "wlan0") or running its own hotspot
     * (interface name varies by device: "wlan0", "ap0", "swlan0", etc).
     */
    private fun getLocalIpAddress(): String {
        try {
            val interfaces = java.net.NetworkInterface.getNetworkInterfaces()
            val otherCandidates = mutableListOf<String>()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (!iface.isUp || iface.isLoopback) continue
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (addr is java.net.Inet4Address && !addr.isLoopbackAddress) {
                        val ip = addr.hostAddress ?: continue
                        // WiFi-client interface ("wlan0") or hotspot/AP interface
                        // ("ap0", "swlan0", etc) - either way this is the address
                        // the other device needs to browse to.
                        val name = iface.name.lowercase()
                        if (name.contains("wlan") || name.contains("ap") || name.contains("swlan")) {
                            return ip
                        }
                        otherCandidates.add(ip)
                    }
                }
            }
            // Fallback: any private-range IPv4 address found on any interface.
            otherCandidates.firstOrNull {
                it.startsWith("192.168.") || it.startsWith("10.") || it.startsWith("172.")
            }?.let { return it }
            otherCandidates.firstOrNull()?.let { return it }
        } catch (e: Exception) {
            // Fall through to the WifiManager fallback below.
        }

        // Last-resort fallback (only correct in plain WiFi-client mode).
        val wifiManager = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        val ipInt = wifiManager.connectionInfo.ipAddress
        return "${ipInt and 0xff}.${ipInt shr 8 and 0xff}.${ipInt shr 16 and 0xff}.${ipInt shr 24 and 0xff}"
    }

    private fun showQr(text: String) {
        val writer = QRCodeWriter()
        val matrix = writer.encode(text, BarcodeFormat.QR_CODE, 512, 512)
        val bmp = Bitmap.createBitmap(512, 512, Bitmap.Config.RGB_565)
        for (x in 0 until 512) {
            for (y in 0 until 512) {
                bmp.setPixel(x, y, if (matrix.get(x, y)) Color.BLACK else Color.WHITE)
            }
        }
        ivQr.setImageBitmap(bmp)
    }
}
