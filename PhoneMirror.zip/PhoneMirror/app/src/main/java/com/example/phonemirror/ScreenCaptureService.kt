package com.example.phonemirror

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import androidx.core.app.NotificationCompat
import java.io.ByteArrayOutputStream

class ScreenCaptureService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var server: MjpegServer? = null
    private var nsdManager: NsdManager? = null
    private var registrationListener: NsdManager.RegistrationListener? = null

    companion object {
        const val CHANNEL_ID = "screen_mirror_channel"
        // Latest captured frame as JPEG bytes - the server reads this to stream to viewers
        @Volatile
        var latestFrameJpeg: ByteArray? = null
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Phone Mirror active")
            .setContentText("Screen is being shared on your local network")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()

        // IMPORTANT: on Android 10+ (and STRICTLY enforced from Android 14 onward),
        // a foreground service declared with foregroundServiceType="mediaProjection"
        // in the manifest MUST be started by passing that same type here. Calling
        // plain startForeground(id, notification) without the type crashes the app
        // instantly and silently on Android 14 devices (e.g. Realme UI 5.0 on the
        // Realme C55) as soon as screen capture is requested - while it still works
        // fine on older Android versions (e.g. Redmi 9 / Redmi A2 on Android 11-13)
        // where this type check isn't enforced.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                1,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(1, notification)
        }

        val resultCode = intent?.getIntExtra("resultCode", Activity_RESULT_OK) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")

        if (data != null) {
            val projectionManager =
                getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, data)

            // Android 14+ also requires a registered callback on the MediaProjection
            // before you create a VirtualDisplay from it, otherwise capture can fail
            // to start on newer OEM builds. stop() here also cleans up if the user
            // revokes the capture permission from the system status bar / notification.
            mediaProjection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    virtualDisplay?.release()
                    virtualDisplay = null
                }
            }, null)

            startCapture()
        }

        // Start the local HTTP/WebSocket server (serves viewer.html, /stream, /control)
        server = MjpegServer(8080, applicationContext)
        server?.start()

        registerNsdService()

        return START_STICKY
    }

    /** Advertises this phone on the local network so "Find Devices" can discover it
     * while it's actively sharing. Unregistered in onDestroy (i.e. when sharing stops). */
    private fun registerNsdService() {
        if (registrationListener != null) return // already registered

        nsdManager = getSystemService(Context.NSD_SERVICE) as NsdManager
        val serviceInfo = NsdServiceInfo().apply {
            serviceName = Build.MODEL ?: "Phone Mirror device"
            serviceType = NsdConstants.SERVICE_TYPE
            port = 8080
        }

        registrationListener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(info: NsdServiceInfo) {}
            override fun onRegistrationFailed(info: NsdServiceInfo, errorCode: Int) {
                registrationListener = null
            }
            override fun onServiceUnregistered(info: NsdServiceInfo) {}
            override fun onUnregistrationFailed(info: NsdServiceInfo, errorCode: Int) {}
        }

        try {
            nsdManager?.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, registrationListener)
        } catch (e: Exception) {
            registrationListener = null
        }
    }

    private fun unregisterNsdService() {
        registrationListener?.let {
            try { nsdManager?.unregisterService(it) } catch (e: Exception) { /* already gone */ }
        }
        registrationListener = null
    }

    private fun startCapture() {
        val metrics = DisplayMetrics()
        val display = (getSystemService(WINDOW_SERVICE) as android.view.WindowManager).defaultDisplay
        display.getRealMetrics(metrics)

        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "PhoneMirror",
            width, height, density,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width

                val bitmap = Bitmap.createBitmap(
                    width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888
                )
                bitmap.copyPixelsFromBuffer(buffer)

                val out = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 50, out)
                latestFrameJpeg = out.toByteArray()
                bitmap.recycle()
            } finally {
                image.close()
            }
        }, null)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Screen Mirror", NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterNsdService()
        server?.stop()
        virtualDisplay?.release()
        mediaProjection?.stop()
    }

    // Called when the user swipes the app away from Recents. Without this,
    // some phones (especially Xiaomi/Oppo/Vivo/OnePlus) kill the process
    // anyway despite stopWithTask="false" in the manifest. Returning here
    // without calling stopSelf() keeps mirroring + control running.
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        // Intentionally do nothing - keep capturing and serving.
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

// Small helper constant (Activity.RESULT_OK == -1) to avoid importing Activity just for this
private const val Activity_RESULT_OK = -1
