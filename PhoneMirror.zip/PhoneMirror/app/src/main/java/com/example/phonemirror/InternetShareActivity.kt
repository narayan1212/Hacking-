package com.example.phonemirror

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class InternetShareActivity : AppCompatActivity() {

    private lateinit var toggleCodeType: MaterialButtonToggleGroup
    private lateinit var toggleQuality: MaterialButtonToggleGroup
    private lateinit var tvQualityHint: TextView
    private lateinit var customCodeLayout: TextInputLayout
    private lateinit var etCustomCode: TextInputEditText
    private lateinit var btnStart: MaterialButton
    private lateinit var btnStop: MaterialButton
    private lateinit var codeResultCard: MaterialCardView
    private lateinit var tvStatus: TextView
    private lateinit var tvCode: TextView

    private val pollHandler = Handler(Looper.getMainLooper())
    private var polling = false

    private val screenCaptureLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val useCustomCode = toggleCodeType.checkedButtonId == R.id.btnCustomCode
                val code = if (useCustomCode) etCustomCode.text?.toString()?.trim().orEmpty() else ""

                if (useCustomCode && code.isEmpty()) {
                    Toast.makeText(this, "Enter a code first", Toast.LENGTH_SHORT).show()
                    return@registerForActivityResult
                }

                val intent = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra("resultCode", result.resultCode)
                    putExtra("data", result.data)
                    putExtra(ScreenCaptureService.EXTRA_RELAY_ENABLED, true)
                    putExtra(ScreenCaptureService.EXTRA_RELAY_CODE, code)
                }
                startForegroundService(intent)
                codeResultCard.visibility = View.VISIBLE
                btnStart.visibility = View.GONE
                btnStop.visibility = View.VISIBLE
                startPolling()
            } else {
                Toast.makeText(this, "Screen capture permission was denied", Toast.LENGTH_SHORT).show()
            }
        }

    private fun setupQualityToggle() {
        val current = RelayClient.getSavedRelayQuality(this)
        val checkedId = when (current) {
            RelayClient.RelayQuality.DATA_SAVER -> R.id.btnQualityDataSaver
            RelayClient.RelayQuality.BALANCED -> R.id.btnQualityBalanced
            RelayClient.RelayQuality.HIGH_QUALITY -> R.id.btnQualityHigh
        }
        toggleQuality.check(checkedId)
        tvQualityHint.text = current.label

        toggleQuality.addOnButtonCheckedListener { _, checkedButtonId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val quality = when (checkedButtonId) {
                R.id.btnQualityDataSaver -> RelayClient.RelayQuality.DATA_SAVER
                R.id.btnQualityHigh -> RelayClient.RelayQuality.HIGH_QUALITY
                else -> RelayClient.RelayQuality.BALANCED
            }
            RelayClient.saveRelayQuality(this, quality)
            tvQualityHint.text = quality.label
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_internet_share)

        findViewById<Toolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }

        toggleCodeType = findViewById(R.id.toggleCodeType)
        customCodeLayout = findViewById(R.id.customCodeLayout)
        etCustomCode = findViewById(R.id.etCustomCode)
        btnStart = findViewById(R.id.btnStartInternetShare)
        btnStop = findViewById(R.id.btnStopInternetShare)
        codeResultCard = findViewById(R.id.codeResultCard)
        tvStatus = findViewById(R.id.tvRelayStatus)
        tvCode = findViewById(R.id.tvCode)
        toggleQuality = findViewById(R.id.toggleQuality)
        tvQualityHint = findViewById(R.id.tvQualityHint)

        toggleCodeType.check(R.id.btnRandomCode)
        setupQualityToggle()

        findViewById<MaterialButton>(R.id.btnAccessibilityInternet).setOnClickListener {
            // Same as the WiFi share screen - Android doesn't allow apps to flip this
            // on programmatically, the user has to do it once manually. Without this,
            // control commands arrive over the relay but nothing on the phone acts on
            // them, since TapAccessibilityService is never actually enabled.
            suppressNextAppOpenAd()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        toggleCodeType.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                customCodeLayout.visibility = if (checkedId == R.id.btnCustomCode) View.VISIBLE else View.GONE
            }
        }

        btnStart.setOnClickListener {
            suppressNextAppOpenAd()
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            screenCaptureLauncher.launch(mgr.createScreenCaptureIntent())
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, ScreenCaptureService::class.java))
            stopPolling()
            codeResultCard.visibility = View.GONE
            btnStart.visibility = View.VISIBLE
            btnStop.visibility = View.GONE
            tvCode.text = "------"
            Toast.makeText(this, "Sharing stopped", Toast.LENGTH_SHORT).show()
        }

        findViewById<MaterialButton>(R.id.btnCopyCode).setOnClickListener {
            val code = tvCode.text?.toString().orEmpty()
            if (code.isNotBlank() && code != "------") {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Phone Mirror code", code))
                Toast.makeText(this, "Code copied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** ScreenCaptureService assigns the code asynchronously once the relay server responds -
     * poll its companion fields on the main thread to reflect that here. */
    private fun startPolling() {
        polling = true
        val poll = object : Runnable {
            override fun run() {
                if (!polling) return
                val code = ScreenCaptureService.relayAssignedCode
                val error = ScreenCaptureService.relayError
                when {
                    error != null -> tvStatus.text = "Error: $error"
                    code != null && ScreenCaptureService.relayPaired -> {
                        tvCode.text = code
                        tvStatus.text = "Connected — the other phone is viewing now"
                    }
                    code != null -> {
                        tvCode.text = code
                        tvStatus.text = "Waiting for the other phone to enter this code..."
                    }
                    else -> tvStatus.text = "Connecting to relay server..."
                }
                pollHandler.postDelayed(this, 1000)
            }
        }
        pollHandler.post(poll)
    }

    private fun stopPolling() {
        polling = false
        pollHandler.removeCallbacksAndMessages(null)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopPolling()
    }
}
