package com.example.phonemirror

import android.content.Context
import android.content.Intent
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class FindDeviceActivity : AppCompatActivity() {

    private data class FoundDevice(val name: String, val host: String, val port: Int)

    private lateinit var listView: ListView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvStatus: TextView
    private lateinit var tvEmpty: TextView

    private val devices = mutableListOf<FoundDevice>()
    private lateinit var adapter: ArrayAdapter<String>

    private lateinit var nsdManager: NsdManager
    private var discoveryListener: NsdManager.DiscoveryListener? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_find_device)

        findViewById<Toolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }
        listView = findViewById(R.id.listDevices)
        progressBar = findViewById(R.id.progressSearching)
        tvStatus = findViewById(R.id.tvSearchStatus)
        tvEmpty = findViewById(R.id.tvEmpty)

        adapter = object : ArrayAdapter<String>(
            this, R.layout.item_device, R.id.tvDeviceName, mutableListOf()
        ) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val view = super.getView(position, convertView, parent)
                val device = devices[position]
                view.findViewById<TextView>(R.id.tvDeviceName).text = device.name
                view.findViewById<TextView>(R.id.tvDeviceAddress).text = "${device.host}:${device.port}"
                return view
            }
        }
        listView.adapter = adapter

        listView.setOnItemClickListener { _, _, position, _ ->
            val device = devices[position]
            val intent = Intent(this, ViewerActivity::class.java)
            intent.putExtra(ViewerActivity.EXTRA_URL, "http://${device.host}:${device.port}")
            intent.putExtra(ViewerActivity.EXTRA_DEVICE_NAME, device.name)
            startActivity(intent)
        }

        nsdManager = getSystemService(Context.NSD_SERVICE) as NsdManager
        startDiscovery()
    }

    private fun startDiscovery() {
        // Multicast lock: some phones ignore mDNS packets while WiFi is in a power-saving
        // state; holding this lock while searching makes discovery reliable across devices.
        val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        multicastLock = wifiManager.createMulticastLock("phonemirror_discovery").apply {
            setReferenceCounted(true)
            acquire()
        }

        discoveryListener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}

            override fun onServiceFound(service: NsdServiceInfo) {
                if (service.serviceType != NsdConstants.SERVICE_TYPE) return
                nsdManager.resolveService(service, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {}
                    override fun onServiceResolved(info: NsdServiceInfo) {
                        val host = info.host?.hostAddress ?: return
                        runOnUiThread {
                            if (devices.none { it.host == host && it.port == info.port }) {
                                devices.add(FoundDevice(info.serviceName, host, info.port))
                                adapter.add(info.serviceName)
                                adapter.notifyDataSetChanged()
                                updateEmptyState()
                            }
                        }
                    }
                })
            }

            override fun onServiceLost(service: NsdServiceInfo) {
                runOnUiThread {
                    val idx = devices.indexOfFirst { it.name == service.serviceName }
                    if (idx >= 0) {
                        devices.removeAt(idx)
                        adapter.remove(adapter.getItem(idx))
                        adapter.notifyDataSetChanged()
                        updateEmptyState()
                    }
                }
            }

            override fun onDiscoveryStopped(serviceType: String) {}

            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                runOnUiThread {
                    Toast.makeText(
                        this@FindDeviceActivity,
                        "Could not search this network (error $errorCode)",
                        Toast.LENGTH_LONG
                    ).show()
                    progressBar.visibility = View.GONE
                    tvStatus.text = "Search failed. You can still enter a link manually."
                }
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
        }

        nsdManager.discoverServices(
            NsdConstants.SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener
        )
    }

    private fun updateEmptyState() {
        tvEmpty.visibility = if (devices.isEmpty()) View.VISIBLE else View.GONE
    }

    override fun onDestroy() {
        super.onDestroy()
        discoveryListener?.let {
            try { nsdManager.stopServiceDiscovery(it) } catch (e: Exception) { /* already stopped */ }
        }
        if (multicastLock?.isHeld == true) multicastLock?.release()
    }
}
