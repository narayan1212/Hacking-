package com.example.phonemirror

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.material.card.MaterialCardView

/**
 * Shown right after the user picks "View Another Screen" on the home screen.
 * Lets them choose whether to view over the local WiFi network (ViewWifiActivity)
 * or over the internet using a relay + code (InternetViewActivity).
 */
class ViewOptionsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_options)

        findViewById<Toolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }

        findViewById<MaterialCardView>(R.id.cardViewWifi).setOnClickListener {
            startActivity(Intent(this, ViewWifiActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardViewInternet).setOnClickListener {
            startActivity(Intent(this, InternetViewActivity::class.java))
        }
    }
}
