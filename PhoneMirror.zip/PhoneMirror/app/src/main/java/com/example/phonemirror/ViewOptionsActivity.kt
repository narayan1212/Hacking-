package com.example.phonemirror

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textfield.TextInputEditText
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

class ViewOptionsActivity : AppCompatActivity() {

    private lateinit var etUrl: TextInputEditText

    // Launches the in-app camera QR scanner (part of our own app, not a separate app)
    // and receives the scanned text back here.
    private val qrScanLauncher = registerForActivityResult(ScanContract()) { result ->
        if (result.contents != null) {
            etUrl.setText(result.contents)
            launchViewer(result.contents)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_options)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.setNavigationOnClickListener { finish() }

        etUrl = findViewById(R.id.etUrl)

        findViewById<MaterialButton>(R.id.btnConnect).setOnClickListener {
            val raw = etUrl.text?.toString()?.trim().orEmpty()
            if (raw.isEmpty()) {
                Toast.makeText(this, "Enter an address first", Toast.LENGTH_SHORT).show()
            } else {
                launchViewer(raw)
            }
        }

        findViewById<MaterialButton>(R.id.btnScanQr).setOnClickListener {
            val options = ScanOptions()
            options.setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            options.setPrompt("Point the camera at the other phone's QR code")
            options.setBeepEnabled(true)
            options.setOrientationLocked(true)
            options.setCaptureActivity(QrScanActivity::class.java)
            qrScanLauncher.launch(options)
        }

        findViewById<MaterialCardView>(R.id.cardFindDevice).setOnClickListener {
            startActivity(Intent(this, FindDeviceActivity::class.java))
        }
    }

    private fun launchViewer(rawAddress: String) {
        val url = normalizeUrl(rawAddress)
        val intent = Intent(this, ViewerActivity::class.java)
        intent.putExtra(ViewerActivity.EXTRA_URL, url)
        startActivity(intent)
    }

    /** Accepts things like "192.168.1.42:8080", "192.168.1.42", or a full URL, and
     * turns them into a proper http:// address the WebView can load. */
    private fun normalizeUrl(input: String): String {
        var url = input.trim()
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "http://$url"
        }
        // If no port was given at all, assume our default port 8080.
        val afterScheme = url.substringAfter("://")
        if (!afterScheme.contains(":") && !afterScheme.contains("/")) {
            url = "$url:8080"
        }
        return url
    }
}
