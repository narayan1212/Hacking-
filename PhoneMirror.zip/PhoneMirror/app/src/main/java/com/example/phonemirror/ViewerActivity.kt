package com.example.phonemirror

import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.material.button.MaterialButton

class ViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URL = "extra_url"
        const val EXTRA_DEVICE_NAME = "extra_device_name"
    }

    private lateinit var webView: WebView
    private lateinit var loadingLayout: View
    private lateinit var errorLayout: View
    private lateinit var toolbar: Toolbar
    private lateinit var targetUrl: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_viewer)

        targetUrl = intent.getStringExtra(EXTRA_URL) ?: run { finish(); return }
        val deviceName = intent.getStringExtra(EXTRA_DEVICE_NAME)

        toolbar = findViewById(R.id.toolbar)
        toolbar.title = deviceName ?: "Connecting..."
        toolbar.setNavigationOnClickListener { finish() }

        webView = findViewById(R.id.webView)
        loadingLayout = findViewById(R.id.loadingLayout)
        errorLayout = findViewById(R.id.errorLayout)

        findViewById<MaterialButton>(R.id.btnRetry).setOnClickListener { load() }

        setupWebView()
        load()
    }

    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadWithOverviewMode = true
            useWideViewPort = true
            // Our server is plain HTTP on the local network by design (no cloud, no
            // TLS cert to manage) - this just tells the WebView engine that's expected.
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                showLoading()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                showContent()
                if (toolbar.title == "Connecting...") {
                    toolbar.title = targetUrl.removePrefix("http://").removePrefix("https://")
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: android.webkit.WebResourceRequest?,
                error: android.webkit.WebResourceError?
            ) {
                // Only treat it as a fatal failure if it's the main page failing to load,
                // not a minor sub-resource (e.g. a favicon) failing.
                if (request?.isForMainFrame == true) {
                    showError()
                }
            }
        }
    }

    private fun load() {
        showLoading()
        webView.loadUrl(targetUrl)
    }

    private fun showLoading() {
        loadingLayout.visibility = View.VISIBLE
        errorLayout.visibility = View.GONE
        webView.visibility = View.INVISIBLE
    }

    private fun showContent() {
        loadingLayout.visibility = View.GONE
        errorLayout.visibility = View.GONE
        webView.visibility = View.VISIBLE
    }

    private fun showError() {
        loadingLayout.visibility = View.GONE
        errorLayout.visibility = View.VISIBLE
        webView.visibility = View.INVISIBLE
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
