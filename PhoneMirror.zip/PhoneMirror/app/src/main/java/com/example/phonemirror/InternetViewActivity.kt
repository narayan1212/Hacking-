package com.example.phonemirror

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PorterDuff
import android.os.Bundle
import android.util.Base64
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import org.json.JSONObject

/**
 * Internet (relay) viewer. The layout and status states are styled to match
 * assets/viewer.html — the UI shown when viewing/controlling over WiFi — so the
 * two connection modes feel like the same app: same header/brand, same status
 * pill states (ok/warn/err), same phone-frame + toolbar-button + panel layout,
 * and the same friendly "connection lost" retry card instead of a bare toast.
 */
class InternetViewActivity : AppCompatActivity() {

    private lateinit var codeEntryLayout: View
    private lateinit var viewerLayout: View
    private lateinit var etCode: TextInputEditText
    private lateinit var tvEntryStatus: TextView

    private lateinit var tvBrandSubtitle: TextView
    private lateinit var ivStatusDot: ImageView
    private lateinit var tvStatus: TextView

    private lateinit var ivScreen: ImageView
    private lateinit var waitingLayout: View
    private lateinit var tvWaitingText: TextView
    private lateinit var errorLayout: View
    private lateinit var tvErrorDetail: TextView
    private lateinit var warningBar: View
    private lateinit var tvWarning: TextView

    private var relayClient: RelayClient? = null
    private var currentBitmap: Bitmap? = null
    private var lastCode: String = ""

    // Tap/swipe tracking, same threshold-based approach as the browser viewer
    private var dragStartX = 0f
    private var dragStartY = 0f
    private var dragStartTime = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_internet_view)

        codeEntryLayout = findViewById(R.id.codeEntryLayout)
        viewerLayout = findViewById(R.id.viewerLayout)
        etCode = findViewById(R.id.etCode)
        tvEntryStatus = findViewById(R.id.tvEntryStatus)

        tvBrandSubtitle = findViewById(R.id.tvBrandSubtitle)
        ivStatusDot = findViewById(R.id.ivStatusDot)
        tvStatus = findViewById(R.id.tvStatus)

        ivScreen = findViewById(R.id.ivScreen)
        waitingLayout = findViewById(R.id.waitingLayout)
        tvWaitingText = findViewById(R.id.tvWaitingText)
        errorLayout = findViewById(R.id.errorLayout)
        tvErrorDetail = findViewById(R.id.tvErrorDetail)
        warningBar = findViewById(R.id.warningBar)
        tvWarning = findViewById(R.id.tvWarning)

        findViewById<Toolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }
        findViewById<ImageButton>(R.id.btnViewerBack).setOnClickListener { disconnectAndReturn() }

        findViewById<MaterialButton>(R.id.btnConnect).setOnClickListener { connect() }
        findViewById<MaterialButton>(R.id.btnRetry).setOnClickListener { retry() }

        findViewById<MaterialButton>(R.id.btnBack).setOnClickListener { sendControl(JSONObject().apply { put("type", "key"); put("action", "back") }) }
        findViewById<MaterialButton>(R.id.btnHome).setOnClickListener { sendControl(JSONObject().apply { put("type", "key"); put("action", "home") }) }
        findViewById<MaterialButton>(R.id.btnRecents).setOnClickListener { sendControl(JSONObject().apply { put("type", "key"); put("action", "recents") }) }

        findViewById<MaterialButton>(R.id.btnSendText).setOnClickListener {
            val text = findViewById<EditText>(R.id.etText).text?.toString().orEmpty()
            if (text.isNotEmpty()) sendControl(JSONObject().apply { put("type", "text"); put("value", text) })
        }

        findViewById<MaterialButton>(R.id.btnOpenUrl).setOnClickListener {
            val url = findViewById<EditText>(R.id.etUrl).text?.toString()?.trim().orEmpty()
            if (url.isNotEmpty()) sendControl(JSONObject().apply { put("type", "openUrl"); put("url", url) })
        }

        ivScreen.setOnTouchListener { _, event -> handleTouch(event); true }
    }

    private fun connect() {
        val code = etCode.text?.toString()?.trim().orEmpty()
        if (code.isEmpty()) { Toast.makeText(this, "Enter a code", Toast.LENGTH_SHORT).show(); return }
        lastCode = code
        tvEntryStatus.text = "Connecting..."
        setStatus("connecting…", StatusLevel.NONE)

        val client = RelayClient(this)
        relayClient = client
        client.connect("register_viewer", code, object : RelayClient.Listener {
            override fun onPaired() {
                runOnUiThread {
                    codeEntryLayout.visibility = View.GONE
                    viewerLayout.visibility = View.VISIBLE
                    tvBrandSubtitle.text = "Code $code"
                    showWaiting("Connected — waiting for the first frame...")
                    setStatus("connected", StatusLevel.OK)
                }
            }

            override fun onMessage(json: JSONObject) {
                when (json.optString("type")) {
                    "frame" -> handleFrame(json.optString("data"))
                    "status" -> handleStatus(json)
                }
            }

            override fun onPeerDisconnected() {
                runOnUiThread {
                    showError("The other phone disconnected.")
                    setStatus("disconnected", StatusLevel.ERR)
                }
            }

            override fun onError(message: String) {
                runOnUiThread {
                    if (viewerLayout.visibility == View.VISIBLE) {
                        showError(message)
                        setStatus("connection error", StatusLevel.ERR)
                    } else {
                        tvEntryStatus.text = message
                    }
                }
            }

            override fun onConnectionClosed() {
                runOnUiThread {
                    if (viewerLayout.visibility == View.VISIBLE) {
                        showError("Connection lost.")
                        setStatus("disconnected — reconnecting…", StatusLevel.ERR)
                    }
                }
            }
        })
    }

    private fun retry() {
        errorLayout.visibility = View.GONE
        if (lastCode.isNotEmpty()) {
            etCode.setText(lastCode)
            connect()
        }
    }

    private fun handleFrame(base64: String) {
        if (base64.isEmpty()) return
        try {
            val bytes = Base64.decode(base64, Base64.NO_WRAP)
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return
            runOnUiThread {
                currentBitmap?.recycle()
                currentBitmap = bitmap
                ivScreen.setImageBitmap(bitmap)
                waitingLayout.visibility = View.GONE
                errorLayout.visibility = View.GONE
            }
        } catch (e: Exception) {
            // skip a malformed/partial frame, the next one will arrive shortly
        }
    }

    private fun handleStatus(json: JSONObject) {
        val enabled = json.optBoolean("accessibilityEnabled", false)
        val stuck = json.optBoolean("stuck", false)
        runOnUiThread {
            if (enabled) {
                warningBar.visibility = View.GONE
                setStatus("connected · control enabled", StatusLevel.OK)
            } else {
                warningBar.visibility = View.VISIBLE
                if (stuck) {
                    tvWarning.text = "Control got stuck on the other phone - it's trying to recover automatically."
                    setStatus("connected · control stuck", StatusLevel.WARN)
                } else {
                    tvWarning.text = "Tap control is off on the other phone. Ask them to enable it in Settings → Accessibility → Phone Mirror."
                    setStatus("connected · control disabled", StatusLevel.WARN)
                }
            }
        }
    }

    private enum class StatusLevel { NONE, OK, WARN, ERR }

    /** Updates the header status pill — mirrors the #status ok/warn/err classes in viewer.html. */
    private fun setStatus(text: String, level: StatusLevel) {
        tvStatus.text = text
        val colorRes = when (level) {
            StatusLevel.OK -> R.color.colorMirrorOk
            StatusLevel.WARN -> R.color.colorMirrorWarn
            StatusLevel.ERR -> R.color.colorMirrorErr
            StatusLevel.NONE -> R.color.colorMirrorTextDim
        }
        ivStatusDot.background.setColorFilter(ContextCompat.getColor(this, colorRes), PorterDuff.Mode.SRC_IN)
    }

    private fun showWaiting(text: String) {
        tvWaitingText.text = text
        waitingLayout.visibility = View.VISIBLE
        errorLayout.visibility = View.GONE
    }

    private fun showError(detail: String) {
        tvErrorDetail.text = detail
        errorLayout.visibility = View.VISIBLE
        waitingLayout.visibility = View.GONE
    }

    private fun sendControl(json: JSONObject) {
        relayClient?.send(json)
    }

    /** Maps a touch point on the ImageView (which uses fitCenter scaling, so the image
     * may be letterboxed) into real coordinates on the mirrored phone's screen. */
    private fun handleTouch(event: MotionEvent) {
        val bitmap = currentBitmap ?: return
        val viewW = ivScreen.width.toFloat()
        val viewH = ivScreen.height.toFloat()
        val bmpW = bitmap.width.toFloat()
        val bmpH = bitmap.height.toFloat()
        if (viewW <= 0 || viewH <= 0) return

        val scale = minOf(viewW / bmpW, viewH / bmpH)
        val displayedW = bmpW * scale
        val displayedH = bmpH * scale
        val offsetX = (viewW - displayedW) / 2f
        val offsetY = (viewH - displayedH) / 2f

        val touchX = event.x - offsetX
        val touchY = event.y - offsetY
        if (touchX < 0 || touchY < 0 || touchX > displayedW || touchY > displayedH) return

        val phoneX = touchX / scale
        val phoneY = touchY / scale

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                dragStartX = phoneX
                dragStartY = phoneY
                dragStartTime = System.currentTimeMillis()
            }
            MotionEvent.ACTION_UP -> {
                val dist = Math.hypot((phoneX - dragStartX).toDouble(), (phoneY - dragStartY).toDouble())
                val duration = (System.currentTimeMillis() - dragStartTime).coerceAtLeast(50)
                if (dist < 15) {
                    sendControl(JSONObject().apply {
                        put("type", "tap"); put("x", dragStartX); put("y", dragStartY)
                    })
                } else {
                    sendControl(JSONObject().apply {
                        put("type", "swipe")
                        put("x1", dragStartX); put("y1", dragStartY)
                        put("x2", phoneX); put("y2", phoneY)
                        put("duration", duration.coerceAtMost(1000))
                    })
                }
            }
        }
    }

    private fun disconnectAndReturn() {
        relayClient?.disconnect()
        relayClient = null
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        relayClient?.disconnect()
        currentBitmap?.recycle()
    }
}
