package com.example.phonemirror

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Base64
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import org.json.JSONObject

class InternetViewActivity : AppCompatActivity() {

    private lateinit var codeEntryLayout: View
    private lateinit var viewerLayout: View
    private lateinit var etCode: TextInputEditText
    private lateinit var tvEntryStatus: TextView
    private lateinit var viewerToolbar: Toolbar
    private lateinit var ivScreen: ImageView
    private lateinit var waitingLayout: View
    private lateinit var tvWaitingText: TextView
    private lateinit var warningBar: View
    private lateinit var tvWarning: TextView
    private lateinit var extraControls: View

    private var relayClient: RelayClient? = null
    private var currentBitmap: Bitmap? = null

    // Tap/swipe tracking, same threshold-based approach as the browser viewer
    private var dragStartX = 0f
    private var dragStartY = 0f
    private var dragStartTime = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_internet_view)

        codeEntryLayout = findViewById(R.id.codeEntryLayout)
        viewerLayout = findViewById(R.id.viewerLayout)
        etCode = findViewById(R.id.etCode)
        tvEntryStatus = findViewById(R.id.tvEntryStatus)
        viewerToolbar = findViewById(R.id.viewerToolbar)
        ivScreen = findViewById(R.id.ivScreen)
        waitingLayout = findViewById(R.id.waitingLayout)
        tvWaitingText = findViewById(R.id.tvWaitingText)
        warningBar = findViewById(R.id.warningBar)
        tvWarning = findViewById(R.id.tvWarning)
        extraControls = findViewById(R.id.extraControls)

        findViewById<Toolbar>(R.id.toolbar).setNavigationOnClickListener { finish() }
        viewerToolbar.setNavigationOnClickListener { disconnectAndReturn() }

        findViewById<MaterialButton>(R.id.btnConnect).setOnClickListener { connect() }

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { sendControl(JSONObject().apply { put("type", "key"); put("action", "back") }) }
        findViewById<ImageButton>(R.id.btnHome).setOnClickListener { sendControl(JSONObject().apply { put("type", "key"); put("action", "home") }) }
        findViewById<ImageButton>(R.id.btnRecents).setOnClickListener { sendControl(JSONObject().apply { put("type", "key"); put("action", "recents") }) }

        findViewById<MaterialButton>(R.id.btnMoreControls).setOnClickListener {
            extraControls.visibility = if (extraControls.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        findViewById<MaterialButton>(R.id.btnSendText).setOnClickListener {
            val text = findViewById<EditText>(R.id.etText).text?.toString().orEmpty()
            if (text.isNotEmpty()) sendControl(JSONObject().apply { put("type", "text"); put("value", text) })
        }

        findViewById<MaterialButton>(R.id.btnOpenUrl).setOnClickListener {
            val url = findViewById<EditText>(R.id.etUrl).text?.toString()?.trim().orEmpty()
            if (url.isNotEmpty()) sendControl(JSONObject().apply { put("type", "openUrl"); put("url", url) })
        }

        ivScreen.setOnTouchListener { _, event -> handleTouch(event); true }
    }

    private fun connect() {
        val code = etCode.text?.toString()?.trim().orEmpty()
        if (code.isEmpty()) { Toast.makeText(this, "Enter a code", Toast.LENGTH_SHORT).show(); return }

        tvEntryStatus.text = "Connecting..."

        val client = RelayClient(this)
        relayClient = client
        client.connect("register_viewer", code, object : RelayClient.Listener {
            override fun onPaired() {
                runOnUiThread {
                    codeEntryLayout.visibility = View.GONE
                    viewerLayout.visibility = View.VISIBLE
                    viewerToolbar.title = "Code $code"
                    tvWaitingText.text = "Connected — waiting for the first frame..."
                }
            }

            override fun onMessage(json: JSONObject) {
                when (json.optString("type")) {
                    "frame" -> handleFrame(json.optString("data"))
                    "status" -> handleStatus(json)
                }
            }

            override fun onPeerDisconnected() {
                runOnUiThread {
                    waitingLayout.visibility = View.VISIBLE
                    tvWaitingText.text = "The other phone disconnected."
                }
            }

            override fun onError(message: String) {
                runOnUiThread {
                    if (viewerLayout.visibility == View.VISIBLE) {
                        Toast.makeText(this@InternetViewActivity, message, Toast.LENGTH_LONG).show()
                    } else {
                        tvEntryStatus.text = message
                    }
                }
            }

            override fun onConnectionClosed() {
                runOnUiThread {
                    if (viewerLayout.visibility == View.VISIBLE) {
                        waitingLayout.visibility = View.VISIBLE
                        tvWaitingText.text = "Connection lost."
                    }
                }
            }
        })
    }

    private fun handleFrame(base64: String) {
        if (base64.isEmpty()) return
        try {
            val bytes = Base64.decode(base64, Base64.NO_WRAP)
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return
            runOnUiThread {
                currentBitmap?.recycle()
                currentBitmap = bitmap
                ivScreen.setImageBitmap(bitmap)
                waitingLayout.visibility = View.GONE
            }
        } catch (e: Exception) {
            // skip a malformed/partial frame, the next one will arrive shortly
        }
    }

    private fun handleStatus(json: JSONObject) {
        val enabled = json.optBoolean("accessibilityEnabled", false)
        val stuck = json.optBoolean("stuck", false)
        runOnUiThread {
            if (enabled) {
                warningBar.visibility = View.GONE
            } else {
                warningBar.visibility = View.VISIBLE
                tvWarning.text = if (stuck) {
                    "Control got stuck on the other phone - it's trying to recover automatically."
                } else {
                    "Tap control is off on the other phone. Ask them to enable it in Settings → Accessibility → Phone Mirror."
                }
            }
        }
    }

    private fun sendControl(json: JSONObject) {
        relayClient?.send(json)
    }

    /** Maps a touch point on the ImageView (which uses fitCenter scaling, so the image
     * may be letterboxed) into real coordinates on the mirrored phone's screen. */
    private fun handleTouch(event: MotionEvent) {
        val bitmap = currentBitmap ?: return
        val viewW = ivScreen.width.toFloat()
        val viewH = ivScreen.height.toFloat()
        val bmpW = bitmap.width.toFloat()
        val bmpH = bitmap.height.toFloat()
        if (viewW <= 0 || viewH <= 0) return

        val scale = minOf(viewW / bmpW, viewH / bmpH)
        val displayedW = bmpW * scale
        val displayedH = bmpH * scale
        val offsetX = (viewW - displayedW) / 2f
        val offsetY = (viewH - displayedH) / 2f

        val touchX = event.x - offsetX
        val touchY = event.y - offsetY
        if (touchX < 0 || touchY < 0 || touchX > displayedW || touchY > displayedH) return

        val phoneX = touchX / scale
        val phoneY = touchY / scale

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                dragStartX = phoneX
                dragStartY = phoneY
                dragStartTime = System.currentTimeMillis()
            }
            MotionEvent.ACTION_UP -> {
                val dist = Math.hypot((phoneX - dragStartX).toDouble(), (phoneY - dragStartY).toDouble())
                val duration = (System.currentTimeMillis() - dragStartTime).coerceAtLeast(50)
                if (dist < 15) {
                    sendControl(JSONObject().apply {
                        put("type", "tap"); put("x", dragStartX); put("y", dragStartY)
                    })
                } else {
                    sendControl(JSONObject().apply {
                        put("type", "swipe")
                        put("x1", dragStartX); put("y1", dragStartY)
                        put("x2", phoneX); put("y2", phoneY)
                        put("duration", duration.coerceAtMost(1000))
                    })
                }
            }
        }
    }

    private fun disconnectAndReturn() {
        relayClient?.disconnect()
        relayClient = null
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        relayClient?.disconnect()
        currentBitmap?.recycle()
    }
}
