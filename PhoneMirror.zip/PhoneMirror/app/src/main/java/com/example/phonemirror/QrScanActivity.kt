package com.example.phonemirror

import com.journeyapps.barcodescanner.CaptureActivity

/**
 * Thin subclass of the zxing-android-embedded scanner so we can give it our own
 * theme/orientation in the manifest, and so the scan happens fully inside our app
 * (no separate scanner app is opened).
 */
class QrScanActivity : CaptureActivity()
