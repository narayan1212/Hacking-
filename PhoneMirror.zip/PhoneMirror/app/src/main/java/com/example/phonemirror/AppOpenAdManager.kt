package com.example.phonemirror

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.os.SystemClock
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import java.util.Date

/**
 * Shows a full-screen ad when the app comes back to the foreground (app switcher,
 * unlocking the phone back into the app, etc.) - not on every single screen change,
 * just process-level foreground transitions, which is what "App Open" ads are for.
 *
 * A couple of safety rules baked in, on top of what Google's own sample does:
 *  - [suppressNextShow] lets an Activity skip the very next opportunity to show an ad,
 *    used right before launching system dialogs (screen capture permission, Accessibility
 *    Settings) so an ad never appears layered over - or immediately after - a permission
 *    prompt, which both looks broken and risks looking like accidental/forced clicks.
 *  - A minimum gap between shows, so rapidly switching apps doesn't spam ads.
 */
class AppOpenAdManager(private val application: Application) : DefaultLifecycleObserver {

    companion object {
        // Real ad unit created in AdMob for this app's "App Open" format.
        private const val AD_UNIT_ID = "ca-app-pub-8398233645882592/5094443334"
        private const val AD_MAX_CACHE_MS = 4 * 60 * 60 * 1000L // Google recommends treating ads older than 4h as stale
        private const val MIN_GAP_BETWEEN_SHOWS_MS = 60_000L
    }

    private var appOpenAd: AppOpenAd? = null
    private var isLoadingAd = false
    private var isShowingAd = false
    private var loadTime: Long = 0L
    private var lastShowElapsedMs: Long = 0L
    private var currentActivity: Activity? = null

    @Volatile
    private var suppressNextShow = false

    init {
        application.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityStarted(activity: Activity) { currentActivity = activity }
            override fun onActivityResumed(activity: Activity) { currentActivity = activity }
            override fun onActivityPaused(activity: Activity) {}
            override fun onActivityStopped(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
        loadAd()
    }

    /** Call right before starting a system permission flow (screen capture, Accessibility
     * Settings) so the ad doesn't fire when the user is sent back into the app afterward. */
    fun suppressNextShow() {
        suppressNextShow = true
    }

    override fun onStart(owner: LifecycleOwner) {
        showAdIfAvailable()
    }

    private fun loadAd() {
        if (isLoadingAd || isAdAvailable()) return
        isLoadingAd = true
        val request = AdRequest.Builder().build()
        AppOpenAd.load(
            application, AD_UNIT_ID, request,
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpenAd = ad
                    isLoadingAd = false
                    loadTime = Date().time
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    isLoadingAd = false
                }
            }
        )
    }

    private fun isAdAvailable(): Boolean {
        return appOpenAd != null && Date().time - loadTime < AD_MAX_CACHE_MS
    }
    private fun showAdIfAvailable() {
        if (isShowingAd) return

        if (suppressNextShow) {
            suppressNextShow = false
            return
        }

        val sinceLastShow = SystemClock.elapsedRealtime() - lastShowElapsedMs
        if (lastShowElapsedMs != 0L && sinceLastShow < MIN_GAP_BETWEEN_SHOWS_MS) return

        val activity = currentActivity ?: return

        if (!isAdAvailable()) {
            loadAd()
            return
        }

        val ad = appOpenAd ?: return
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                appOpenAd = null
                isShowingAd = false
                loadAd()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                appOpenAd = null
                isShowingAd = false
                loadAd()
            }

            override fun onAdShowedFullScreenContent() {
                isShowingAd = true
                lastShowElapsedMs = SystemClock.elapsedRealtime()
            }
        }
        ad.show(activity)
    }
}

/** Convenience so any Activity can call `suppressNextAppOpenAd()` right before launching
 * a system permission dialog, without needing to reach into Application manually. */
fun Activity.suppressNextAppOpenAd() {
    (application as? PhoneMirrorApplication)?.appOpenAdManager?.suppressNextShow()
}
