package com.example.phonemirror

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * A single outbound WebSocket connection to the relay server, used for "Internet Mode".
 * Both the sharing phone (host) and the viewing phone (viewer) use this same class -
 * only the registration message and what they do with incoming messages differ.
 *
 * This is the ONLY part of the app that talks to a server outside the local WiFi
 * network. Every other feature (local sharing/viewing) never uses this class.
 */
class RelayClient(private val context: Context) {

    companion object {
        // Fixed relay server used for all "Internet Mode" connections. There is no
        // in-app field to edit this anymore - it always runs in the background.
        const val RELAY_URL = "wss://phonemirror-relay.onrender.com"
    }

    interface Listener {
        fun onRegistered(code: String) {}
        fun onPaired() {}
        fun onPeerDisconnected() {}
        fun onMessage(json: JSONObject) {}
        fun onError(message: String) {}
        fun onConnectionClosed() {}
    }

    private var webSocket: WebSocket? = null
    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS) // WebSocket stays open indefinitely
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    /** role: "register_host" or "register_viewer". code: blank for host = server picks a random one. */
    fun connect(role: String, code: String, listener: Listener) {
        val request = Request.Builder().url(RELAY_URL).build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                val register = JSONObject().apply {
                    put("type", role)
                    put("code", code)
                }
                ws.send(register.toString())
            }

            override fun onMessage(ws: WebSocket, text: String) {
                try {
                    val json = JSONObject(text)
                    when (json.optString("type")) {
                        "registered" -> listener.onRegistered(json.optString("code"))
                        "paired" -> listener.onPaired()
                        "peer_disconnected" -> listener.onPeerDisconnected()
                        "error" -> listener.onError(json.optString("message", "Connection error"))
                        else -> listener.onMessage(json)
                    }
                } catch (e: Exception) {
                    // ignore malformed messages
                }
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                listener.onError(t.message ?: "Could not reach the relay server")
                listener.onConnectionClosed()
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                listener.onConnectionClosed()
            }
        })
    }

    fun send(json: JSONObject) {
        webSocket?.send(json.toString())
    }

    fun disconnect() {
        webSocket?.close(1000, "closed by app")
        webSocket = null
    }
}
