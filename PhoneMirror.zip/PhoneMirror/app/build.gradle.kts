plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.phonemirror"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.phonemirror"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")

    // Lightweight embedded HTTP + WebSocket server (runs ON the phone)
    implementation("org.nanohttpd:nanohttpd:2.3.1")
    implementation("org.nanohttpd:nanohttpd-websocket:2.3.1")

    // QR code generation to show phone's local IP easily
    implementation("com.google.zxing:core:3.5.2")

    // In-app QR code SCANNING (opens a camera scanner inside our own app,
    // not a separate app) for the "View another screen" flow
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")

    // WebSocket CLIENT (outbound connection) used only for "Internet Mode" -
    // lets a phone connect OUT to the relay server across different networks.
    // Everything else in the app still uses the local server (NanoHTTPD) and
    // never needs this.
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
