# Phone Mirror — Local WiFi Screen Mirror + Remote Tap Control

No cloud server, no internet needed — everything runs on the phone itself over
your local WiFi network, like ApowerMirror's local mode.

## How it works
1. Phone runs a tiny embedded web server (`MjpegServer.kt`) on port 8080.
2. Phone screen is captured with Android's `MediaProjection` API and streamed
   as an MJPEG video feed at `http://<phone-ip>:8080/stream`.
3. Open `http://<phone-ip>:8080` in any browser on a laptop/PC on the **same
   WiFi network** — you'll see the phone's live screen.
4. The viewer page gives you full remote control, not just viewing:
   - **Tap**: click on the mirrored screen (e.g. clicking the YouTube icon
     opens YouTube on the real phone)
   - **Swipe/scroll**: click-drag (or touch-drag) across the mirrored screen
   - **Back / Home / Recents** buttons
   - **Open URL on phone**: type a URL (e.g. `youtube.com`) in the "Open on
     phone" box — it opens directly on the real phone via an Android Intent,
     regardless of what's on the mirrored screen
   - **Send text**: tap a text field on the phone first (via the mirrored
     screen) so it's focused, then type in the "Send text" box and hit send
   - All of this happens over a WebSocket to Android's `AccessibilityService`,
     which is the only component Android allows to inject taps/gestures/text
     on behalf of another app

## Setup
1. Open this folder in **Android Studio**.
2. Let Gradle sync (downloads the NanoHTTPD + ZXing dependencies).
3. Run the app on a real Android phone (min SDK 26 / Android 8+).
   MediaProjection/screen capture does not work reliably on the emulator.
4. On first launch:
   - Tap **"Enable Tap Control (Accessibility)"** and turn on "Phone Mirror"
     in Settings → Accessibility. Android *requires* this to be done manually
     by the user — no app can enable it silently, as an anti-malware
     protection.
   - Tap **"Start Mirroring"** and accept the screen-capture permission
     prompt (Android also requires this every session, by design).
   - The viewer page (browser) will show a clear orange warning banner if
     the Accessibility Service isn't on yet, so it's obvious when control
     won't work — screen viewing works regardless, but tap/swipe/text/URL
     control needs it enabled.
5. The app shows the phone's local IP and a QR code. On your laptop (same
   WiFi/hotspot), open that address in a browser.

## Known limitations of this starter version
- Both devices must be on the same WiFi network (or phone hotspot).
- MJPEG over HTTP is simple and reliable but not as bandwidth-efficient as a
  proper WebRTC stream — fine for local network use; noticeable lag if you
  push it over the internet later.
- No pairing/auth — anyone on the same WiFi who has the IP can view/control
  it while mirroring is active. Fine for personal/home use; add a
  password/token check in `MjpegServer.kt` before using on shared networks.
- **Surviving "swipe from Recents":** the app is set to keep running after
  being removed from Recents (`stopWithTask="false"` + `onTaskRemoved`
  override). On stock Android this is enough. On **Xiaomi/MIUI,
  Oppo/ColorOS, Vivo/FuntouchOS, OnePlus** and similar, you may also need to
  manually:
  - Turn off battery optimization for the app (Settings → Battery → Phone
    Mirror → "No restrictions" / "Don't optimize")
  - Enable "Autostart" / "Allow background activity" for the app in the
    phone's security/battery app
  Without this, the phone's own battery manager can still kill the app a
  few minutes after it's backgrounded, regardless of what the app itself
  does.

## Extending it
- **Better performance**: swap the MJPEG pipeline for WebRTC using an Android
  WebRTC library if you need lower latency / lower bandwidth.
- **Auth**: add a shared password/token check at the top of `serveHttp()` and
  `openWebSocket()` in `MjpegServer.kt` if using this outside a trusted network.
